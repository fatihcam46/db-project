create type aq$_jms_userproperty
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
9e be
dQnF08C0REARKTs8QTNiDmUnuJkwg5n0dLhcWlbD9HKXYkqWYtxixRaXllpixSbDj8B0K6W/
m8Ayy+4ljwlppcfSMlyprHzGyhcoxsqyhB0dLqQOceeFLxal0pn7vUQHNpUHrZJGRWY+eGWp
5f6ZgQIM4THc4jXKzJbGfMYwTcxnXlMhO4imxlobAg==
/

