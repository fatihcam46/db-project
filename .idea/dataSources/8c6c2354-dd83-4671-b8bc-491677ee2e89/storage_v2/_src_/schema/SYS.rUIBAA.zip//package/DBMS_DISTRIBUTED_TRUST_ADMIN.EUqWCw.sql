create package dbms_distributed_trust_admin is

  procedure allow_all;
  procedure deny_all;
  procedure allow_server(server in varchar2);
  procedure deny_server(server in varchar2);

end;
/

