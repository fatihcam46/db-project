create type aq$_jms_exception
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
92 b6
jQg0PYDmFTVtQpkufvgWaEThd/Uwg5n0dLhcWlbD9HKXYkquO1rcYhb6R3Jej8B0K6W/m8Ay
y+4ljwlppfXMqR2daQ9JscqkRA5L9qJnNE+MZNVaV0d/hTFqf1pqhd1nXlsUH46Ou/2K4qlW
F56NmctS9TNAq1u3gn+m8sDeo4KmpsgEqEc=
/

