create PACKAGE dbms_dbverify authid current_user IS

-- DE-HEAD     <- tell SED where to cut when generating fixed package

  PROCEDURE dbv2(fname       IN   varchar2
                ,start_blk   IN   binary_integer
                ,end_blk     IN   binary_integer
                ,blocksize   IN   binary_integer
                ,output      IN OUT  varchar2
                ,error       IN OUT  varchar2
                ,stats       IN OUT  varchar2);

  -- Verify blocks in datafile
  --
  --   Input parameters
  --     fname - Datafile to scan
  --     start - Start block address
  --     end - End block address
  --     blocksize - Logical block size
  --     outout - Output message buffer
  --     error - Error message buffer
  --     stats - Stats message buffer

-------------------------------------------------------------------------------
  pragma TIMESTAMP('2004-03-29:18:43:00');
-------------------------------------------------------------------------------

END;

-- CUT_HERE    <- tell sed where to chop off the rest
/

