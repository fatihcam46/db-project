create PACKAGE dbms_defer_sys AS
  -------------------
  --  OVERVIEW
  --
  -- This package is the system administrator  interface to a replicated
  -- transactional deferred remote
  -- procedure call facility.  Administrators and replication
  -- deamons can execute
  -- transactions queued for remote nodes using this facility
  -- and administrators
  -- can control the nodes to which remote calls are destined.
  ------------
  --  SECURITY
  --
  -- By default, this package is owned by user SYS and
  -- execution should be granted
  -- only to administrators and deamons that perform
  -- replication administration and
  -- execute deferred transactions.  See the security considerations for
  -- the dbms_defer package for related considerations.
  -------------
  --  EXCEPTIONS
  --
  --  Parameter type does not match actual type. Message varies.
  crt_err_err EXCEPTION;
  PRAGMA exception_init(crt_err_err, -23324);
  crt_err_num NUMBER := -23324;
  crt_err_msg  VARCHAR(76) := 'Error creating deferror entry: ';

  --  Replication is not linked as an option
  norepoption EXCEPTION;
  PRAGMA exception_init(norepoption, -2094);
  norepoption_num NUMBER := -2094;

  -- Invalid user
  missinguser EXCEPTION;
  PRAGMA exception_init(missinguser, -23362);
  missinguser_num NUMBER := -23362;

  -- Already the propagator
  alreadypropagator EXCEPTION;
  PRAGMA exception_init(alreadypropagator, -23393);
  alreadypropagator_num NUMBER := -23393;

  -- Duplicate propagator
  duplicatepropagator EXCEPTION;
  PRAGMA exception_init(duplicatepropagator, -23394);
  duplicatepropagator_num NUMBER := -23394;

  -- Missing propagator
  missingpropagator EXCEPTION;
  PRAGMA exception_init(missingpropagator, -23357);
  missingpropagator_num NUMBER := -23357;

  -- Propagator in use
  propagator_inuse EXCEPTION;
  PRAGMA exception_init(propagator_inuse, -23418);
  propagator_inuse_num NUMBER := -23418;

  -- Incomplete parallel propagation/push, added for bug 430300
  incompleteparallelpush EXCEPTION;
  PRAGMA exception_init(incompleteparallelpush, -23388);
  incompleteparallelpush_num NUMBER := -23388;

  -- purge queue argument is out of range
  argoutofrange EXCEPTION;
  PRAGMA exception_init(argoutofrange, -23427);
  argoutofrange_num NUMBER := -23427;

  -- there are deferred RPC for some destination
  notemptyqueue EXCEPTION;
  PRAGMA exception_init(notemptyqueue, -23426);
  notemptyqueue_num NUMBER := -23426;

  -- serial propagation can not be used
  serialpropnotallowed EXCEPTION;
  PRAGMA exception_init(serialpropnotallowed, -23495);
  serialpropnotallowed_num NUMBER := -23495;

  cantsetdisabled EXCEPTION;
  PRAGMA exception_init(cantsetdisabled, -23496);
  cantsetdisabled_num NUMBER := -23496;

  -------------
  --  CONSTANTS

  --
  -- constants for result of push or purge
  --
  result_ok                    BINARY_INTEGER := 0;
    -- okay, terminated after delay_seconds expired
  result_startup_seconds       BINARY_INTEGER := 1;
    -- terminated by lock timeout while starting
  result_execution_seconds     BINARY_INTEGER := 2;
    -- terminated by exceeding execution_seconds
  result_transaction_count     BINARY_INTEGER := 3;
    -- terminated by exceeding transaction_count
  result_delivery_order_limit  BINARY_INTEGER := 4;
    -- terminated at delivery_order_limit
  result_errors                BINARY_INTEGER := 5;
    -- terminated after errors
  result_push_disabled         BINARY_INTEGER := 6;
    -- terminated after detecting that propagation is disabled
  result_purge_disabled        BINARY_INTEGER := 6;
    -- terminated after detecting that purge is disabled
  result_cant_get_sr_enq       BINARY_INTEGER := 7;
    -- terminated after failing to acquire SR enqueue

  --
  -- constants for purge_method in purge_queue
  --
  purge_method_quick   BINARY_INTEGER := 1;
  purge_method_precise BINARY_INTEGER := 2;
  --
  -- constants for parameter defaults
  --
  seconds_infinity          BINARY_INTEGER := 60*60*24*180;
  transactions_infinity     BINARY_INTEGER := 1000000000;
  delivery_order_infinity   NUMBER := 100000000000000000000;

  --  PROCEDURES

  -- manage default replication node lists

  PROCEDURE add_default_dest(dblink IN VARCHAR2);
  --  Add a node to the default list for replication targets.
  --  Input parameters
  --    dblink
  --      name of the node (dblink) to add tRo the default list.
  --  Exceptions
  --    ORA-23352
  --     dblink is already in the default list.
  ----------

  PROCEDURE delete_default_dest(dblink IN VARCHAR2);
  --  Delete a node from the default list for replication targets
  --  Input parameters
  --    dblink
  --      name of the node (dblink) to delete from the default list.
  --      Operation is a no-op if dblink is not in the list.
  --  Exceptions
  --    none.
  -----------------

  FUNCTION push(
      destination          IN VARCHAR2,
      parallelism          IN BINARY_INTEGER := 0,
      heap_size            IN BINARY_INTEGER := 0,
      stop_on_error        IN BOOLEAN := FALSE,
      write_trace          IN BOOLEAN := FALSE,
      startup_seconds      IN BINARY_INTEGER := 0,
      execution_seconds    IN BINARY_INTEGER := seconds_infinity,
      delay_seconds        IN BINARY_INTEGER := 0,
      transaction_count    IN BINARY_INTEGER := transactions_infinity,
      delivery_order_limit IN NUMBER := delivery_order_infinity
  ) RETURN BINARY_INTEGER;
  --
  -- Push transactions queued for destination node, choosing either
  --   serial or parallel propagation.
  --
  -- Parameters:
  --   destination
  --     name of destination (dblink) to push to
  --   parallelism
  --     max degree of parallelism of the push
  --     0 = (old algorithm) serial propagation
  --     1 = (new algorithm) parallel propagation with only 1 slave
  --     n = (new algorithm) parallel propagation with n slaves
  --   heap_size
  --     if > 0, max number of txns to be examined simultaneously for
  --     parallel scheduling computation; default is to compute this
  --     from specified parallelism
  --   stop_on_error
  --     stop on first error even if not fatal
  --   write_trace
  --     record execution result value and non-fatal errors in trace file
  --   startup_seconds
  --     max secs to wait for another instance of push
  --     (pushing to the same destination) to finish
  --   execution_seconds
  --     shutdown cleanly after this many seconds of real time
  --   delay_seconds
  --     shutdown cleanly if queue is empty for this long
  --   transaction_count
  --     shutdown cleanly after pushing this many transactions
  --   delivery_order_limit
  --     shutdown cleanly before pushing a transaction with
  --     delivery_order >= delivery_order_limit
  --
  -- Result:
  --   a value from the constants
  --     dbms_defer_sys.result_%
  --   indicating how the push completed
  --
  ----------------

  PROCEDURE execute(destination       IN VARCHAR2,
                    stop_on_error     IN BOOLEAN := FALSE,
                    transaction_count IN BINARY_INTEGER := 0,
                    execution_seconds IN BINARY_INTEGER := 0,
		    execute_as_user   IN BOOLEAN,
                    delay_seconds     IN NATURAL := 0,
                    batch_size        IN NATURAL := 0);
  -- The execute_as_user parameter is obsolete and ignored.
  -----------------

  PROCEDURE execute(destination       IN VARCHAR2,
                    stop_on_error     IN BOOLEAN := FALSE,
                    transaction_count IN BINARY_INTEGER := 0,
                    execution_seconds IN BINARY_INTEGER := 0,
                    delay_seconds     IN NATURAL := 0,
                    batch_size        IN NATURAL := 0);
  --  Execute transactions queued for destination_node using the security
  --  context of the propagator. stop_on_error
  --  determines whether processing of subsequent transaction continues
  --  after an error is detected.
  --  deftrandest (and defcalldest if appropriate) entries
  --  for the successfully executed transactions are deleted and if there
  --  are no other references, the defcall and deftran entries are deleted.
  --
  --  Input Parameters:
  --    destination
  --      node (dblink) at which to execute
  --      deferred transaction.  Case
  --      insensitive comparisons used.
  --    stop_on_error
  --      If TRUE, execution of queued transactions will
  --      alway stop when an error is
  --      encountered, leaving unattempted transaction in
  --      the queue.  If FALSE,
  --      execution continues except when errors that appear
  --      to mean that node is
  --      unavailable are encountered, it which case execution
  --      always stops, leaving
  --      unattempted transactions queued.
  --    transaction_count
  --      If positive, at most this many transactions will be executed.
  --    executions_seconds
  --      If positive, execution will stop after completions of the
  --      last transaction after this many seconds of executions.
  --    delay_seconds
  --      If positive, the routine will sleep for this many seconds before
  --      returning when it finds no deferred RPCs queued for the destination
  --      Non-zero values can reduce execution overhead compared to calling
  --      dbms_defer_sys.execute from a tight loop.
  --    batch_size
  --      The number of deferred rpc calls should be executed before
  --      committing deferred transactions.  If batch_size is 0 a commit will
  --      occur after each deferred transaction.  If batch_size is greater than
  --      zero a commit will occur when the total number of deferred calls
  --      executed exceeds batch_size and a complete transaction has been
  --      executed.
  --
  --  Exceptions
  --    Raises the last exception encountered before execution
  --    stops because of
  --    an exception.
  ----------------

  PROCEDURE execute_error(deferred_tran_id IN VARCHAR2,
                          destination      IN VARCHAR2);
  --  (Re)Execute transactions that previously encountered conflicts.
  --  Each transaction is executed in the security context of the original
  --  receiver of the transaction.
  --  Execution stops when any error is encountered.  If some input is null,
  --  then each transaction is committed as it completes. If exactly one
  --  transaction is specified, then the transactions is not committed.
  --  Upon successful execution, transactions are removed for deferror, and if
  --  there are no other references, entries are deleted from
  --  defcall and deftran.
  --  Input Parameters:
  --    deferred_tran_id
  --      The identifier of the transaction to be reexecuted.
  --      If null then all transactions in deferror matching
  --      destination (as specified) are re-executed.
  --    destination
  --      dblink that transaction was originally destined to.
  --      Must not be null.
  --  Exceptions
  --    Raises an exception if destination is null.
  --    Raises an exception if the original receiver is an invalid user.
  --    Raises the last exception encountered before execution
  --    stops because of an exception.
  ----------------

  PROCEDURE execute_error_as_user(deferred_tran_id IN VARCHAR2,
                                  destination      IN VARCHAR2);
  --  (Re)Execute transactions that previously encountered conflicts.
  --  Each transaction is executed in the security context of the connected
  --  user.
  --  Execution stops when any error is encountered.  If some input is null,
  --  then each transaction is committed as it completes. If exactly one
  --  transaction is specified, then the transactions is not committed.
  --  Upon successful execution, transactions are removed for deferror, and if
  --  there are no other references, entries are deleted from
  --  defcall and deftran.
  --  Input Parameters:
  --    deferred_tran_id
  --      The identifier of the transaction to be reexecuted.
  --      If null then all transactions in deferror matching
  --      destination (as specified) are re-executed.
  --    destination
  --      dblink that transaction was originally destined to.
  --      Must not be null.
  --  Exceptions
  --    Raises an exception if destination is null.
  --    Raises the last exception encountered before execution
  --    stops because of an exception.
  ----------------

  PROCEDURE delete_tran(deferred_tran_id IN VARCHAR2,
                        destination      IN VARCHAR2);
  --  Delete transactions from  queues. Deletes deftrandest (and defcalldest
  --  entries if appropriate.  If there are not other references,
  --  deftran and defcall entries are deleted.
  --  Input Parameters:
  --    destination
  --      dblink for which transaction(s) are to be removed from queues.
  --      If null, the transaction specified by the other parameters are
  --      deleted from queues for all destinations.
  --    deferred_tran_id
  --      The identifier of the transaction to be deleted
  --      If null then all transactions matching destination
  --      are deleted.
  --  Exceptions
  --    tid and/or node not found.
  ---------------
  PROCEDURE delete_error(deferred_tran_id IN VARCHAR2,
                         destination      IN VARCHAR2);

  --  Delete transactions from  deferror table. If there are
  --  not other references,
  --  deftran and defcall entries are deleted.
  --  Input Parameters:
  --    destination
  --      destination for which transaction(s) are to be removed from
  --      deferror.
  --      If null, the transaction specified by the other parameters are
  --      deleted from deferror for all destinations.
  --    deferred_tran_id
  --      The identifier of the transaction to be deleted
  --      If null then all transactions matching destination and
  --      are deleted.
  --  Exceptions
  --    tid and/or node not found.
  ---------------

  PROCEDURE schedule_execution(dblink         IN VARCHAR2,
                               interval       IN VARCHAR2,
                               next_date      IN DATE,
                               reset          IN BOOLEAN default FALSE,
                               stop_on_error  IN BOOLEAN := NULL,
                               transaction_count IN BINARY_INTEGER := NULL,
                               execution_seconds IN BINARY_INTEGER := NULL,
            		       execute_as_user   IN BOOLEAN,
                               delay_seconds     IN NATURAL := NULL,
                               batch_size        IN NATURAL := NULL);
  -- The execute_as_user parameter is obsolete and ignored.
  -----------------

  PROCEDURE schedule_execution(dblink         IN VARCHAR2,
                               interval       IN VARCHAR2,
                               next_date      IN DATE,
                               reset          IN BOOLEAN default FALSE,
                               stop_on_error  IN BOOLEAN := NULL,
                               transaction_count IN BINARY_INTEGER := NULL,
                               execution_seconds IN BINARY_INTEGER := NULL,
                               delay_seconds     IN NATURAL := NULL,
                               batch_size        IN NATURAL := NULL);
  -- Insert or update a defschedule entry and signal the background process.
  -- this procedure does a commit;
  -- Input Parameters:
  --   dblink
  --     Queue name to schedule execution for;
  --   interval
  --     If non-null then DefSchedule.interval for dblink is set to this
  --     value. If null and the DefSchedule entry for dblink exists,
  --     the value of DefSchedule.interval is not modified. If
  --     null and the DefSchedule entry
  --     for dblink does not exist, then the DefSchedule entry for
  --     dblink is created with a null interval value.
  --   next_date
  --     If non-null then DefSchedule.next_date for dblink is set to this
  --     value. If null and the DefSchedule entry for dblink exists, the value
  --     of DefSchedule.next_date is not modified. If null and
  --     the DefSchedule entry
  --     for dblink does not exist, then the DefSchedule entry
  --     for dblink is created with a null next_date value.
  --   reset
  --     If TRUE then last_txn_count, last_error, and last_msg are nulled.
  --    stop_on_error
  --    transaction_count
  --    execution_seconds
  --    delay_seconds
  --    batch_size
  --      If non-null, these parameters are passed to the
  --      dbms_defer_sys.execute call that is scheduled for execution by
  --      this call.
  -----------------

  PROCEDURE schedule_push(
      destination          IN VARCHAR2,
      interval             IN VARCHAR2,
      next_date            IN DATE,
      reset                IN BOOLEAN := FALSE,
      parallelism          IN BINARY_INTEGER := NULL,
      heap_size            IN BINARY_INTEGER := NULL,
      stop_on_error        IN BOOLEAN := NULL,
      write_trace          IN BOOLEAN := NULL,
      startup_seconds      IN BINARY_INTEGER := NULL,
      execution_seconds    IN BINARY_INTEGER := NULL,
      delay_seconds        IN BINARY_INTEGER := NULL,
      transaction_count    IN BINARY_INTEGER := NULL
  );
  --
  -- Schedule a job to invoke push
  --
  -- Parameters:
  --   interval
  --     used to calculate the next next_date, via
  --       select _interval_ into next_date from dual;
  --   next_date
  --     the next date that the queue will be pushed
  --     to the specified destination
  --   reset
  --     if TRUE then last_txn_count, last_error, and last_msg
  --     are nulled in the def$_destination row for the
  --     specified destination
  --
  --   remaining parameters are as for push
  -----------------

  PROCEDURE unschedule_execution(dblink         IN VARCHAR2);
  --  Delete a defschedule entry. Signal to background process to stop
  --  servicing this queue.
  --  Obsolescent; use unschedule_push, below.
  -- Input Parameters:
  --   dblink
  --     Queue name to stop automatic execution of.
  -- Exceptions:
  --   NO_DATA_FOUND
  --     no entry for dblink in DefSchedule.
  -----------------

  PROCEDURE unschedule_push(dblink IN VARCHAR2);
  --  Delete a defschedule entry.
  --  Signal to background process to stop servicing this queue.
  --  Input Parameters:
  --   dblink
  --     Queue name to stop automatic execution of.
  --  Exceptions:
  --   NO_DATA_FOUND
  --     no entry for dblink in DefSchedule.
  -----------------

  FUNCTION disabled(destination IN VARCHAR2,
                    catchup     IN RAW := '00') RETURN BOOLEAN;
  --
  --   Test whether disabled for given destination.
  --
  --   Parameters:
  --     destination or NULL (which implicitly identifies the purge row)
  --     catchup: extension ID if any
  --   Returns:
  --     TRUE iff the deferred RPC queue is disabled for the given
  --     destination.
  --
  --   Raises the following exceptions:
  --       no_data_found:
  --          if the "destination" does not appear in defschedule.
  -----------------

  PROCEDURE set_disabled(destination IN VARCHAR2,
                         disabled    IN BOOLEAN := TRUE,
                         catchup     IN RAW := '00',
                         override    IN BOOLEAN := FALSE);
  --
  --   Turn on/off the disabled state for a destination.
  --
  --   Parameters:
  --     destination
  --       name of dest site, or NULL (implicitly identifies the purge row)
  --     disabled
  --       on/off
  --     catchup
  --       extension ID if any
  --     override
  --       see comment below
  --       WARNING: Do not set this parameter unless directed to do so by
  --                Oracle Support Services.
  --
  --     If "disabled" is TRUE, disable propagation to the given
  --   "destination." All future invocations of dbms_defer_sys.execute
  --   will not be able to push the deferred RPC queue to this
  --   destination until it is enabled.  This function has no effect
  --   on a session already pushing the queue to the given
  --   destination.  This function has no effect on sessions appending
  --   to the queue with dbms_defer.
  --     If "disabled" is FALSE, enable propagation to the given "destination."
  --   Although this does not push the queue, it permits future invocations
  --   of dbms_defer_sys.execute to push the queue to the given destination.
  --     In either case, a COMMIT is required for this to take effect in other
  --   sessions.
  --   If "override" is TRUE, it ignores whether the disabled state
  --   was set internally for synchronization and always tries to set
  --   the state as specified by the "disabled" parameter.
  --
  --   Raises the following exceptions:
  --      no_data_found:
  --        if the "destination" does not appear in defschedule.
  --      dbms_defer_sys.cantsetdisabled:
  --        if the disabled was set internally for synchronization.
  -----------------

  PROCEDURE register_propagator(username IN VARCHAR2);
  -- Register the given user as the propagator for the local database. It
  -- also grants to the given user CREATE SESSION, CREATE PROCEDURE,
  -- CREATE DATABASE LINK and EXECUTE ANY PROCEDURE
  -- privileges (so that the user can create wrappers).
  -- It ensures that only one user is the propagator.  It ignores any existing
  -- invalid propagator that may be in the catalog.
  -- Input Parameters:
  --   username
  --     Name of the user
  -- Exceptions:
  --   missinguser
  --     The given user does not exist.
  --   alreadypropagator
  --     The given user is already the propagator.
  --   duplicatepropagator
  --     There is already a different propagator.
  -----------------

  PROCEDURE unregister_propagator(username IN VARCHAR2,
                                  timeout  IN INTEGER
                                                    DEFAULT dbms_lock.maxwait);
  -- Unregister the given user as the given propagator for the local database.
  -- It also revokes all privileges that were granted by register_propagator()
  -- from the given user, including those identical privileges that were
  -- granted independently of register_propagator().
  -- It drops any existing genereted wrappers in the schema of the given
  -- propagator, and marks them as dropped in the replication catalog.
  -- If the propagator is in use, it will wait until the provided timeout
  -- (in seconds), then an exception will be raised.
  -- Input Parameters:
  --   username
  --     Name of the user
  --   timeout
  --     Timeout in seconds.  If the propagator is in use, it will wait until
  --     the given timeout.  The default value is dbms_lock.maxwait.
  -- Exceptions:
  --   missingpropagator
  --     The given user is not the propagator.
  --   propagator_inuse
  --     The propagator is in use, thus cannot be unregistered. Try later.
  -----------------

  FUNCTION exclude_push(timeout IN INTEGER) RETURN INTEGER;
  -- Acquire an exclusive lock that prevents deferred transaction push
  --   (either serial or parallel).
  --
  -- Input:
  --   timeout
  --     Timeout in seconds.  If the lock cannot be acquired within this
  --     time period (either because of an error or because a push is
  --     currently under way) then the call returns a value of 1 (see
  --     below).
  --     A timeout value of dbms_lock.maxwait waits forever.
  -- Return value (lock held?):
  --   (as for dbms_lock.acquire(.))
  --     0 - success (Y)
  --     1 - timeout (N)
  --     2 - deadlock (N)
  --     4 - already own the lock (Y)
  --
  -- Note:
  --   ** this function does a commit **
  --   The lock is acquired with release_on_commit=>TRUE, so pushing may
  --   resume after the next commit.
  -----------------

  PROCEDURE delete_def_destination(destination IN VARCHAR2,
                                   force IN BOOLEAN := FALSE,
                                   catchup IN RAW := NULL);
  -- This procedure is to delete a row in system.def$_destination.
  -- It is used to get rid of some destination which is not active (no
  -- replication activities) and will not be active for a significant amount
  -- of time. Without that entry in def$_destination, purge_method_quick will
  -- serve its purpose by being able to purge effectively.
  --
  -- Input:
  --   destination: the row with dblink to be deleted
  --
  --   force: ignore any safety check and delete the row anyway
  --
  --   catchup: catchup value for the destination to be deleted.
  --            If null, all the rows matching destination will be deleted.
  --
  -- Notes:
  --   1. To do that, we need to lock the site-specific lock for pushing to
  --      make sure no one is pushing at that time.
  --   2. To avoid repushing transactions after a site is deleted and then
  --      added back, we make sure there are no transactions for this site
  --      (regardless whether the transactions have been pushed or not)
  --   3. To avoid deleting the destination after an incomplete (unclean)
  --      parallel push, we have an explicit check on that.
  --   4. If force is TRUE, we will ignore condition (2) and (3). What it means
  --      is unless you are absolutely sure you want to get rid of the site
  --      (destination) and there is NO transaction for it and parallel push is
  --      clean, do NOT set force to TRUE. Otherwise, you may end up
  --      repushing some transactions.
  --   5. To delete a dblink which has some repschema and D-type transaction,
  --      you need to remove the repschema and push, purge the D-type
  --      transaction first.
  --   6. There is no commit in this procedure. So, the caller can rollback
  --      the change if necessary.
  ------------------

  FUNCTION purge(
      purge_method      IN BINARY_INTEGER := purge_method_quick,
      rollback_segment  IN VARCHAR2 := NULL,
      startup_seconds   IN BINARY_INTEGER := 0,
      execution_seconds IN BINARY_INTEGER := seconds_infinity,
      delay_seconds     IN BINARY_INTEGER := 0,
      transaction_count IN BINARY_INTEGER := transactions_infinity,
      write_trace       IN BOOLEAN := FALSE
  ) RETURN BINARY_INTEGER;

  -- Purge pushed transactions from the queue
  --
  -- Parameters:
  --   purge_method
  --     a value controlling cost-precision tradeoff; either
  --     purge_method_quick or purge_method_precise
  --   rollback_segment
  --     rollback segment to use while purging the queue
  --   startup_seconds
  --     max secs to wait for another instance of push
  --     (pushing to the same destination) to finish
  --   execution_seconds
  --     shutdown cleanly after this many seconds of real time
  --   delay_seconds
  --     shutdown cleanly if queue is empty for this long
  --   transaction_count
  --     shutdown cleanly after purging this many transactions
  --   write_trace
  --     record result value in trace file
  --
  -- Result:
  --   a value from the constants
  --     dbms_defer_sys.result_%
  --   indicating how the purge completed
  --
  -- Exception:
  --   argoutofrange(-23427): "argument '%s' is out of range"
  ----------

  PROCEDURE schedule_purge(
      interval          IN VARCHAR2,
      next_date         IN DATE,
      reset             IN BOOLEAN := FALSE,
      purge_method      IN BINARY_INTEGER := NULL,
      rollback_segment  IN VARCHAR2 := NULL,
      startup_seconds   IN BINARY_INTEGER := NULL,
      execution_seconds IN BINARY_INTEGER := NULL,
      delay_seconds     IN BINARY_INTEGER := NULL,
      transaction_count IN BINARY_INTEGER := NULL,
      write_trace       IN BOOLEAN := NULL
  );
  --
  -- Schedule a job to invoke purge
  --
  -- Parameters:
  --   interval
  --     used to calculate the next next_date, via
  --       select _interval_ into next_date from dual;
  --   next_date
  --     the next date that the queue will be pushed
  --     to the specified destination
  --   reset
  --     if TRUE then last_txn_count, last_error, and last_msg
  --     are nulled in the "purge" def$_destination row, i.e.,
  --     the row for this site's unqualified global name.
  --
  --   other parameters as for purge
  --

  -------------------------------------------------------------------------

  PROCEDURE unschedule_purge;
  --
  --   Delete defschedule entry for purge.
  --   Signal to background process to stop servicing purge.
  --

  -------------------------------------------------------------------------

  PROCEDURE clear_prop_statistics(dblink in VARCHAR2);
  --
  -- Clear the statistics of a destination in defschdule. This procedure
  -- will clear the following information from defschedule:
  --
  -- total_txn_count
  -- avg_throughput
  -- avg_latency
  -- total_bytes_sent
  -- total_bytes_received
  -- total_round_trips
  -- total_admin_count
  -- total_error_count
  -- total_sleep_time
  --
  -- Parameters :
  --   dblink
  --     The destination whose statistics in defschedule are to be cleared.
  --

  -------------------------------------------------------------------------

  PROCEDURE nullify_trans_to_destination(dblink IN VARCHAR2,
                                         catchup IN RAW := NULL);
  --   For internal use only.

  -------------------------------------------------------------------------

  PROCEDURE nullify_all_trans;
  --   For internal use only.

  PROCEDURE execute_error_call_as_user(deferred_tran_id IN VARCHAR2,
                                       callno           IN NUMBER);
  --   For internal use only.

  PROCEDURE execute_error_call(deferred_tran_id IN VARCHAR2,
                               callno           IN NUMBER);
  --   For internal use only.

  FUNCTION push_with_catchup(
      destination          IN VARCHAR2,
      parallelism          IN BINARY_INTEGER := 0,
      heap_size            IN BINARY_INTEGER := 0,
      stop_on_error        IN BOOLEAN := FALSE,
      write_trace          IN BOOLEAN := FALSE,
      startup_seconds      IN BINARY_INTEGER := 0,
      execution_seconds    IN BINARY_INTEGER := seconds_infinity,
      delay_seconds        IN BINARY_INTEGER := 0,
      transaction_count    IN BINARY_INTEGER := transactions_infinity,
      delivery_order_limit IN NUMBER := delivery_order_infinity,
      catchup              IN RAW := NULL
  ) RETURN BINARY_INTEGER;
  --   For internal use only.

END dbms_defer_sys;
/

