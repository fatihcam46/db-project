create type chnf$_rdesc as object(
   opflags number,
   row_id varchar2(2000))
/

