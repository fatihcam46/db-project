create PACKAGE dbms_defer_query AS
  -------------------
  --  OVERVIEW
  --
  -- This package permits querying the deferred RPC queue data that
  -- is not exposed through views.

  -------------
  --  CONSTANTS
  --
  --     constants used in the arg_type column of the def$_args table
  --     definitions copied from dtydef.h
  --
  arg_type_num       CONSTANT NUMBER := 2;   -- DTYNUM
  arg_type_char      CONSTANT NUMBER := 96;  -- DTYAFC
  arg_type_varchar2  CONSTANT NUMBER := 1;   -- DTYCHAR
  arg_type_date      CONSTANT NUMBER := 12;  -- DTYDAT
  arg_type_rowid     CONSTANT NUMBER := 11;  -- DTYRID
  arg_type_raw       CONSTANT NUMBER := 23;  -- DTYBIN
  arg_type_blob      CONSTANT NUMBER := 113; -- DTYBLOB
  arg_type_clob      CONSTANT NUMBER := 112; -- DTYCLOB
  arg_type_bfil      CONSTANT NUMBER := 114; -- DTYBFIL
  arg_type_cfil      CONSTANT NUMBER := 115; -- DTYCFIL
  arg_type_time      CONSTANT NUMBER := 178; -- DTYTIME
  arg_type_ttz       CONSTANT NUMBER := 179; -- DTYTTZ
  arg_type_timestamp CONSTANT NUMBER := 180; -- DTYSTAMP
  arg_type_tstz      CONSTANT NUMBER := 181; -- DTYSTZ
  arg_type_iym       CONSTANT NUMBER := 182; -- DTYIYM
  arg_type_ids       CONSTANT NUMBER := 183; -- DTYIDS
  arg_type_tsltz     CONSTANT NUMBER := 231; -- DTYSITZ
  -----------
  -- the following constants are added for replicated objects
  --
  arg_type_object_null_vector    CONSTANT NUMBER := 121; -- DTYADT
  -- anydata includes instance for VARRAY, Nested Table, Object Type, REF Type
  -- and Opaque type.
  arg_type_anydata              CONSTANT NUMBER := 109; -- DTYINTY

  -- constants derived from SQLCS_% constants in sqldef.h
  arg_csetid_none       CONSTANT NUMBER := 0; -- DATE, NUMBER, ROWID, RAW, BLOB
                                              -- user-defined types
  arg_form_none         CONSTANT NUMBER := 0; -- DATE, NUMBER, ROWID, RAW, BLOB
                                              -- user-defined types
  arg_form_implicit     CONSTANT NUMBER := 1; -- CHAR, VARCHAR2, CLOB
  arg_form_nchar        CONSTANT NUMBER := 2; -- NCHAR, NVARCHAR2, NCLOB
  arg_form_any          CONSTANT NUMBER := 4;
  --     definition same as dbms_repcat_mas.repcat_status_normal
  --     (don't want to require repcat to be loaded)
  repcat_status_normal  CONSTANT NUMBER := 0.0;

  -- The following type declaration are used by get_call_args call.
  TYPE type_ary is table of number
	index by binary_integer;

  TYPE val_ary is table of varchar2(2000)
	index by binary_integer;

  FUNCTION get_arg_type(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2)
    RETURN NUMBER;
  -- Return type  of a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id
  ----
  --  Result
  --    The type of the deferred rpc parameter.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  ------

  FUNCTION get_arg_csetid(callno           IN  NUMBER,
                          arg_no           IN  NUMBER,
                          deferred_tran_id IN  VARCHAR2)
    RETURN NUMBER;
  -- Return the character set id of a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id
  ----
  --  Result
  --    The character set id of the deferred rpc parameter.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  ------

  FUNCTION get_arg_form(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2)
    RETURN NUMBER;
  -- Return the character set form of a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id
  ----
  --  Result
  --    The character set form of the deferred rpc parameter.
  --    Examples include dbms_defer.arg_form_implicit and
  --    dbms_defer.arg_form_nchar.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  ------
  FUNCTION get_number_arg(callno           IN  NUMBER,
                          arg_no           IN  NUMBER,
                          deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN NUMBER;
  -- Return a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a number.
  -------
  FUNCTION get_varchar2_arg(callno           IN  NUMBER,
                            arg_no           IN  NUMBER,
                            deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a VARCHAR2.
  -------
  FUNCTION get_nvarchar2_arg(callno           IN  NUMBER,
                             arg_no           IN  NUMBER,
                             deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN NVARCHAR2;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not an NVARCHAR2.
  -------
  FUNCTION get_char_arg(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN CHAR;
  -- Return type  of a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a char.
  -------
  FUNCTION get_nchar_arg(callno           IN  NUMBER,
                         arg_no           IN  NUMBER,
                         deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN NCHAR;
  -- Return type  of a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not an nchar.
  -------
  FUNCTION get_date_arg(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN DATE;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a date.
  -------
  FUNCTION get_raw_arg(callno            IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN RAW;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a raw.
  -------
  FUNCTION get_rowid_arg(callno           IN  NUMBER,
                         arg_no           IN  NUMBER,
                         deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN ROWID;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a rowid.
  -------
  FUNCTION get_blob_arg(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN BLOB;
  -- Return a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a blob.
  -------
  FUNCTION get_clob_arg(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN CLOB;
  -- Return a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a clob.
  -------
  FUNCTION get_nclob_arg(callno           IN  NUMBER,
                         arg_no           IN  NUMBER,
                         deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN NCLOB;
  -- Return a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not an nclob.
  -------
  FUNCTION get_time_arg(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN TIME_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a time.
  -------
  FUNCTION get_timestamp_arg(callno           IN  NUMBER,
                             arg_no           IN  NUMBER,
                             deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN TIMESTAMP_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not a timestamp.
  -------
  FUNCTION get_ttz_arg(callno           IN  NUMBER,
                       arg_no           IN  NUMBER,
                       deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN TIME_TZ_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not time with time zone.
  -------
  FUNCTION get_tstz_arg(callno           IN  NUMBER,
                        arg_no           IN  NUMBER,
                        deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN TIMESTAMP_TZ_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not timestamp with time zone.
  -------
  FUNCTION get_tsltz_arg(callno           IN  NUMBER,
                         arg_no           IN  NUMBER,
                         deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN TIMESTAMP_LTZ_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not timestamp with local
  --    time zone.
  -------
  FUNCTION get_iym_arg(callno           IN  NUMBER,
                       arg_no           IN  NUMBER,
                       deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN yminterval_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not interval year to month.
  -------
  FUNCTION get_ids_arg(callno           IN  NUMBER,
                       arg_no           IN  NUMBER,
                       deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN DSINTERVAL_UNCONSTRAINED;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not interval day to second.
  -------
  FUNCTION get_object_null_vector_arg(
                            callno           IN  NUMBER,
                            arg_no           IN  NUMBER,
                            deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN system.repcat$_object_null_vector;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter .
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not an object_null_vector type
  -------
  FUNCTION get_anydata_arg(callno           IN  NUMBER,
                           arg_no           IN  NUMBER,
                           deferred_tran_id IN  VARCHAR2 DEFAULT NULL)
    RETURN Sys.AnyData;
  -- Return  a deferred call parameter.
  -- Input parameters
  --  callno
  --    call identifier from the defCall view
  --  arg_no
  --    position of desired parameter in calls argument list
  --    parameter positions are 1..number of parameters in call
  --  deferred_tran_id
  --    deferred transaction id, defaults to one passed in get_arg_type
  ----
  --  Result
  --    The value of the parameter.
  --  Notes
  --    Supported types include Collections, Object types, REF types and
  --    opaque types.
  --    Not all types supported by get_anydata_arg can be enqueued
  --    using anydata_arg.
  ------
  --  EXCEPTIONS
  --    NO_DATA_FOUND desired parameter value not found in the deferred rpc
  --    queue tables.
  --    WRONG_TYPE if the desired parameter is not one of the types that
  --    can be handled by anydata type
  -------
  PROCEDURE get_call_args
       (
	callno IN NUMBER,		-- deferred call number
	startarg IN NUMBER := 1,	 -- starting argument to fetch
	argcnt IN NUMBER,		-- number of arguments in the call
	argsize IN NUMBER,	 	-- maximum size of returned argument
	tran_db IN VARCHAR2,	        -- origin database
	tran_id IN VARCHAR2,	        -- transaction id
	date_fmt IN VARCHAR2,	        -- date format
	types OUT TYPE_ARY,		-- output array for types
                                        -- of the arguments
	vals OUT VAL_ARY		-- output array of the values
       );
  -- This procedure returns the text version of the various arguments for the
  -- given call. The exceptions returned by this function are the same ones
  -- as returned by get_arg_type and get _xxx_arg.
  -- This is obsolete in V8.

  PROCEDURE get_call_args
       (
	callno IN NUMBER,		-- deferred call number
	startarg IN NUMBER := 1,	 -- starting argument to fetch
	argcnt IN NUMBER,		-- number of arguments in the call
	argsize IN NUMBER,	 	-- maximum size of returned argument
	tran_id IN VARCHAR2,	        -- transaction id
	date_fmt IN VARCHAR2,	        -- date format
        time_fmt IN VARCHAR2,           -- time format
        ttz_fmt  IN VARCHAR2,           -- time with time zone format
        timestamp_fmt IN VARCHAR2,      -- timestamp format
        tstz_fmt IN VARCHAR2,           -- timestamp with time zone format
	types OUT TYPE_ARY,		-- output array for types
                                        -- of the arguments
        forms OUT TYPE_ARY,             -- output array for forms
                                        -- of the arguments
	vals OUT VAL_ARY		-- output array of the values
       );
  -- This procedure returns the text version of the various arguments for the
  -- given call. The exceptions returned by this function are the same ones
  -- as returned by get_arg_type and get _xxx_arg.

  PROCEDURE get_call_args
       (
	callno        IN  NUMBER,       -- deferred call number
	startarg      IN  NUMBER := 1,  -- starting argument to fetch
	argcnt        IN  NUMBER,       -- number of arguments in the call
	argsize       IN  NUMBER,       -- maximum size of returned argument
	tran_id       IN  VARCHAR2,     -- transaction id
	date_fmt      IN  VARCHAR2,     -- date format
        time_fmt      IN  VARCHAR2,     -- time format
        ttz_fmt       IN  VARCHAR2,     -- time with time zone format
        timestamp_fmt IN  VARCHAR2,     -- timestamp format
        tstz_fmt      IN  VARCHAR2,     -- timestamp with time zone format
        tsltz_fmt     IN  VARCHAR2,     -- timestamp with local timezone format
	types         OUT TYPE_ARY,     -- output array for types
                                        -- of the arguments
        forms         OUT TYPE_ARY,     -- output array for forms
                                        -- of the arguments
	vals          OUT VAL_ARY       -- output array of the values
       );
  -- This procedure returns the text version of the various arguments for the
  -- given call. The exceptions returned by this function are the same ones
  -- as returned by get_arg_type and get _xxx_arg.

END dbms_defer_query;
/

