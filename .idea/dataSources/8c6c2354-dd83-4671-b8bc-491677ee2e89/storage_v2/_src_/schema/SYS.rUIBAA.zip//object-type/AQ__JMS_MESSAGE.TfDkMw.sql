create type aq$_jms_message
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
109 fb
J8GAUKWxuei8pyqcrFnpN09yJlwwg0zwfyisfC8CkPjVSHCp2/v0E+sNcTZmDs1EkScE4/S9
1u61SW+6sginEjoZ7RJ6cb3U6pFPTuDB3pPUxjbhsqDCZpVmb6ZEONyrFY9iwlx52LASwf0n
bsXHu79NXDd7bSje7NifLtSPWFZkXGnfNObo2gWZKiK2DnZ1R9BIltpEqprQ3jC7hKv40Luf
bhBiDyXyLFzceaPhp9zjXaASHQumAFQ=
/

