create PACKAGE dbms_datapump_utl wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
74 9a
0GQpqmKdox8vb7kKTA8fNGnF9rMwg0z6f8upynSmZxeHryRuxTvU54OOdf3wjBQbFbVM8MQc
1rpwZhIcQ7PHZPhVlzs7h29Rf1YT70fmPL01ZumrqPgaVwy1eagzj/mu1aN25sNGNm4d9ty8
u4eSaagy
/

