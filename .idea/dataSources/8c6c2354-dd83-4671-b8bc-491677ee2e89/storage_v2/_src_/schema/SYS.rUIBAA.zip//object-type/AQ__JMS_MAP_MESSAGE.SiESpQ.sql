create type aq$_jms_map_message
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
82 ae
zXz2G8NAEJ1oZkMBPQLrWVyAphEwg5n0dLhcWlbD9HKXYkpyLlbjci5i0dxZrlyPwHQrpb+b
wDLL7iWPCWmluDL1UrIJpvvGZ40wlpqPMOPIy2klPmXbKlcZxj2uNa/rljao010E4g6mFCFf
dHR0IffDktr7WGfxDOvs+6ZsZ6iC
/

