create PACKAGE blast_cur AS
  TYPE refcur_t IS REF CURSOR;
  TYPE seqdbrec_t IS RECORD (
    sequence_id VARCHAR2(4000),
    sequence_db CLOB
  );
  TYPE seqdbcur_t IS REF CURSOR RETURN seqdbrec_t;
END blast_cur;
/

