create package dbms_dnfs AUTHID CURRENT_USER AS

-- DE-HEAD  <- tell SED where to cut when generating fixed package


  -- Renames files in the dNFS test database to the new name. The new file
  -- points to the original file for reads.
  --
  -- srcfile - source data file name in the control file
  -- destfile - destination file
  --
  PROCEDURE clonedb_renamefile (srcfile  IN varchar2,
                                destfile  IN varchar2
                                );

-------------------------------------------------------------------------------

pragma TIMESTAMP('2010-07-08:12:00:00');

-------------------------------------------------------------------------------


end;

-- CUT_HERE    <- tell sed where to chop off the rest
/

