create PACKAGE BODY dbms_dblink wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
bd e3
Ws2veL6/jxzo0/1YsE80N8bJ+IYwg0xfLp4VfC8CTMGOhOojQOIb+mmEBSFZtqAK4KHzoZSz
kLDE8x9mIIHtJAfl1BhnnyOpV0xPC26n2WL7M+H5FN1SsFpbG+fi4Hc2yTv7IREKyCDDG21i
NfeHUqHuPz9uBnHP8mBlm6ajYXNNAQt+AOKHSsvUuzUyPOuzF5+FHgdJucQPv+qeNSu1StnX
/dpDluc=
/

