create function database_name return varchar2 is
begin
return dbms_standard.database_name;
end;
/

