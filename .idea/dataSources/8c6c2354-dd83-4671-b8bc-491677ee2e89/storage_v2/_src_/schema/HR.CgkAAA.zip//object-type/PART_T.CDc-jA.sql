create TYPE PART_T 
    AS OBJECT 
    ( 
        SYS_XDBPD$ XDB$RAW_LIST_T , 
        PART_NUMBER VARCHAR2 (14) , 
        QUANTITY NUMBER (8,4) , 
        UNITPRICE NUMBER (12,2) 
    ) NOT FINAL 
;
/

