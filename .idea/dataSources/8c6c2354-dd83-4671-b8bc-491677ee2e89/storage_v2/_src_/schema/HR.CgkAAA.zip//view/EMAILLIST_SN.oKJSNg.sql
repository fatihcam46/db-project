create view EMAILLIST_SN as
select substr(FIRST_NAME,0,1)||'.'||substr(LAST_NAME,0,1) as "initials",
FIRST_NAME||' '||LAST_NAME as "fulname", lower(EMAIL||'@gmail.com') as "full_email"
from EMPLOYEES
/

