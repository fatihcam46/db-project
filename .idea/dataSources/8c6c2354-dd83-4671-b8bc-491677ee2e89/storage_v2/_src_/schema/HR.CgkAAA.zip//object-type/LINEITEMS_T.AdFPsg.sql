create TYPE LINEITEMS_T 
    AS OBJECT 
    ( 
        SYS_XDBPD$ XDB$RAW_LIST_T , 
        LINEITEM LINEITEM_V 
    ) NOT FINAL 
;
/

