create trigger WWV_FLOW_VERSION_T1
    before insert
    on WWV_FLOW_VERSION$
    for each row
begin
    select wwv_flow_version_seq.nextval,sysdate into :new.seq,:new.date_applied from dual;
end;
/

