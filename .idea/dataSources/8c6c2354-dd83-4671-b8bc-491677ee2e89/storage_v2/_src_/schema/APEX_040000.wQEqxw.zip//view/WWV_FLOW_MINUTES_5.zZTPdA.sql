create view WWV_FLOW_MINUTES_5 (MINUTE_VALUE) as
select (i-1)*5 from wwv_flow_dual100 where i < 13
/

