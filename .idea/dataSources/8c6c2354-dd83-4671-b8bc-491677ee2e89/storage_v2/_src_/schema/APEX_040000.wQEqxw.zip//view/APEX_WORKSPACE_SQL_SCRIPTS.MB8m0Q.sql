create view APEX_WORKSPACE_SQL_SCRIPTS as
select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    f.filename                  sql_script_name,
    (select max(email_address)
    from wwv_flow_fnd_user
    where security_group_id = w.PROVISIONING_COMPANY_ID
    and user_name=f.created_by) email,
    --
    --f.title                     file_name,
    f.mime_type                 mime_type,
    f.doc_size                  file_size,
    f.created_by                owner,
    f.blob_content              sql_script
from
    wwv_flow_file_objects$ f,
    wwv_flow_companies w
where
    f.security_group_id = w.PROVISIONING_COMPANY_ID and
    to_char(f.deleted_as_of,'MM.DD.YYYY') = '01.01.0001' and
    f.file_type = 'SCRIPT' and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS','SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_WORKSPACE_SQL_SCRIPTS is 'Identifies SQL Scripts used to execute SQL and PL/SQL commands'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.WORKSPACE_NAME is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.SQL_SCRIPT_NAME is 'Identifies name of the SQL Script'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.EMAIL is 'Identifies email address that corresponds to the APEX User Name who owns the SQL Script'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.MIME_TYPE is 'Mime type associated with the file'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.FILE_SIZE is 'Size of the file in the BLOB'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.OWNER is 'Identifies the APEX User Name who crated and owns the SQL Script'
/

comment on column APEX_WORKSPACE_SQL_SCRIPTS.SQL_SCRIPT is 'The SQL Script file'
/

