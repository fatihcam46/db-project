create package wwv_flow_ws_sample
is
procedure deinstall (
	p_security_group_id in number,
	p_id in number);

procedure install (
	p_name              in varchar2,
	p_security_group_id in number,
	p_id in number);
end;
/

