create trigger WWV_FLOW_FEEDBACK_T2
    after delete
    on WWV_FLOW_FEEDBACK
    for each row
begin
    if wwv_flow.g_workspace_delete_in_progress = FALSE then
	      delete from wwv_flow_team_tags where component_id = :old.id;
	  end if;
end wwv_flow_feedback_t2;
/

