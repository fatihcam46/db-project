create view WWV_FLOW_MONTHS_MONTH as
select "MONTH_DISPLAY","MONTH_VALUE" from wwv_flow_months_month_temp where month_value < 13
/

