create package wwv_flow_ws_security

is

function get_current_user_role
    return varchar2;

function current_user_is_not_reader
    return boolean;

function current_user_is_reader
    return boolean;

function current_user_is_devenv
    return boolean;

function current_user_is_admin
    return boolean;

function admin_exists(
    p_username         in varchar2 default null,
    p_websheet_app_id  in number)
    return boolean;

procedure authenticate (
    p_websheet_app_id  in number,
    p_websheet_page_id in number default null);

procedure create_auth_setup (
    p_websheet_app_id     in number,
    p_submitted_auth_type in varchar2);

procedure update_auth_setup(
    p_websheet_app_id in number);

function ws_auth_type(
    p_websheet_application_id in number)
    return varchar2;

function ws_acl_type(
    p_websheet_application_id in number)
    return varchar2;

function ws_allow_public(
    p_websheet_application_id in number)
    return boolean;

function sql_enabled (
    p_ws_app_id  in number) return boolean;

function sql_enabled_yn (
    p_ws_app_id  in number) return varchar2;

function sql_enabled_inst return boolean;

function sql_enabled_inst_yn return varchar2;

function is_valid_sql (
    p_ws_app_id  in number,
    p_type       in varchar2,
    p_sql        in varchar2 default null,
    p_schema     in varchar2 default null,
    p_table_name in varchar2 default null) return varchar2;

function is_valid_ws_query (
    p_ws_app_id     in number,
    p_sql           in varchar2) return varchar2;

function str_contains_valid_sql (
    p_ws_app_id    in number,
    p_string       in varchar2) return varchar2;

end wwv_flow_ws_security;
/

