create view APEX_APPLICATION_BREADCRUMBS as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    m.NAME                           breadcrumb_name,
    --
    (select count(*) from wwv_flow_menu_options where menu_id = m.id) breadcrumb_entries,
    --
    m.LAST_UPDATED_BY                last_updated_by,
    m.LAST_UPDATED_ON                last_updated_on,
    m.MENU_COMMENT                   component_comment,
    m.id                             breadcrumb_id,
    --
    m.NAME
    component_signature
from wwv_flow_menus m,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = m.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_BREADCRUMBS is 'Identifies the definition of a collection of Breadcrumb Entries which are used to identify a page Hierarchy'
/

comment on column APEX_APPLICATION_BREADCRUMBS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_BREADCRUMBS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_BREADCRUMBS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_BREADCRUMBS.BREADCRUMB_NAME is 'Identifies the Breadcrumb Name, a breadcrumb is a collection of Breadcrumb Entries used to show page context.'
/

comment on column APEX_APPLICATION_BREADCRUMBS.BREADCRUMB_ENTRIES is 'Count of Entries defined for this Breadcrumb'
/

comment on column APEX_APPLICATION_BREADCRUMBS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_BREADCRUMBS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_BREADCRUMBS.COMPONENT_COMMENT is 'Developer Comment'
/

comment on column APEX_APPLICATION_BREADCRUMBS.BREADCRUMB_ID is 'Primary key of this Breadcrumb'
/

comment on column APEX_APPLICATION_BREADCRUMBS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

