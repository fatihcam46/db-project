create view APEX_APPL_PLUGINS as
select p.id                        as plugin_id,
       f.workspace,
       f.application_id,
       f.application_name,
       case p.plugin_type
         when 'ITEM TYPE'          then 'Item Type'
         when 'DYNAMIC ACTION'     then 'Dynamic Action'
         when 'REGION TYPE'        then 'Region Type'
         when 'REPORT COLUMN TYPE' then 'Report Column Type'
         when 'VALIDATION TYPE'    then 'Validation Type'
         when 'PROCESS TYPE'       then 'Process Type'
         else                       p.plugin_type
       end                         as plugin_type,
       p.name,
       p.display_name,
       p.category,
       p.image_prefix              as file_prefix,
       p.plsql_code,
       p.render_function,
       p.ajax_function,
       p.validation_function,
       p.execution_function,
       p.builder_validation_function,
       p.migration_function,
       p.standard_attributes,
       p.sql_min_column_count,
       p.sql_max_column_count,
       p.sql_examples,
       p.attribute_01,
       p.attribute_02,
       p.attribute_03,
       p.attribute_04,
       p.attribute_05,
       p.attribute_06,
       p.attribute_07,
       p.attribute_08,
       p.attribute_09,
       p.attribute_10,
       nvl2(p.reference_id, 'Yes', 'No') as is_subscribed,
       ( select s.flow_id||'. '||s.display_name
           from wwv_flow_plugins s
          where s.id = p.reference_id )  as subscribed_from,
       p.reference_id                    as subscribed_from_id,
       p.help_text,
       p.version_identifier,
       p.about_url,
       p.plugin_comment                  as component_comment,
       p.created_by,
       p.created_on,
       p.last_updated_by,
       p.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p
 where p.flow_id = f.application_id
/

comment on table APEX_APPL_PLUGINS is 'Stores the meta data for the plug-ins of an application.'
/

comment on column APEX_APPL_PLUGINS.PLUGIN_ID is 'Identifies the primary key of this component'
/

comment on column APEX_APPL_PLUGINS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPL_PLUGINS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPL_PLUGINS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPL_PLUGINS.PLUGIN_TYPE is 'Type of the plug-in.'
/

comment on column APEX_APPL_PLUGINS.NAME is 'Internal name of the plug-in which is used to reference it for example in apex_application_page_items.'
/

comment on column APEX_APPL_PLUGINS.DISPLAY_NAME is 'Contains the name of the plug-in which is displayed on the UI.'
/

comment on column APEX_APPL_PLUGINS.CATEGORY is 'Category under which the plug-in should displayed on the UI.'
/

comment on column APEX_APPL_PLUGINS.FILE_PREFIX is 'File prefix which is used by the plug-in to load additional files like CSS, Javascript and images.'
/

comment on column APEX_APPL_PLUGINS.PLSQL_CODE is 'PL/SQL code which contains the logic of the plug-in.'
/

comment on column APEX_APPL_PLUGINS.RENDER_FUNCTION is 'During rendering of the page this function is called to render the plug-in.'
/

comment on column APEX_APPL_PLUGINS.AJAX_FUNCTION is 'Function which is called for a plug-in when there is an incoming AJAX call from the browser.'
/

comment on column APEX_APPL_PLUGINS.VALIDATION_FUNCTION is 'Function which is called to validate the plug-ins data before the defined validations are fired.'
/

comment on column APEX_APPL_PLUGINS.EXECUTION_FUNCTION is 'Function which is called for plug-ins that are just used on the server side.'
/

comment on column APEX_APPL_PLUGINS.BUILDER_VALIDATION_FUNCTION is 'Function which is called to validate the entered attribute values in the builder.'
/

comment on column APEX_APPL_PLUGINS.MIGRATION_FUNCTION is 'Function which is called when a new version of a plug-in is installed to migrate existing attribute values.'
/

comment on column APEX_APPL_PLUGINS.STANDARD_ATTRIBUTES is 'Contains the APEX provided standard attributes which should be displayed for the plug-in.'
/

comment on column APEX_APPL_PLUGINS.SQL_MIN_COLUMN_COUNT is 'Minimum number of columns the SQL query of the LOV or region source has to have.'
/

comment on column APEX_APPL_PLUGINS.SQL_MAX_COLUMN_COUNT is 'Maximum number of columns the SQL query of the LOV or region source can have.'
/

comment on column APEX_APPL_PLUGINS.SQL_EXAMPLES is 'LOV or region source SQL examples which are displayed for the plug-in in the Builder.'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_01 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_02 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_03 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_04 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_05 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_06 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_07 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_08 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_09 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.ATTRIBUTE_10 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPL_PLUGINS.IS_SUBSCRIBED is 'Identifies if this plug-in is subscribed from another plug-in'
/

comment on column APEX_APPL_PLUGINS.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPL_PLUGINS.SUBSCRIBED_FROM_ID is 'Id the master component from which this component is subscribed'
/

comment on column APEX_APPL_PLUGINS.HELP_TEXT is 'Help text which is displayed for the plug-in in the Builder.'
/

comment on column APEX_APPL_PLUGINS.VERSION_IDENTIFIER is 'Version identifier of the plug-in.'
/

comment on column APEX_APPL_PLUGINS.ABOUT_URL is 'URL to get additional information about the plug-in.'
/

comment on column APEX_APPL_PLUGINS.COMPONENT_COMMENT is 'Developer Comment'
/

comment on column APEX_APPL_PLUGINS.CREATED_BY is 'APEX developer who created the plug-in'
/

comment on column APEX_APPL_PLUGINS.CREATED_ON is 'Date of creation'
/

comment on column APEX_APPL_PLUGINS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPL_PLUGINS.LAST_UPDATED_ON is 'Date of last update'
/

