create package wwv_flow_ws_webpage
as

g_tree                  wwv_flow_plugin_util.t_column_value_list; -- for use with jstrees
g_running_data_section  boolean := false;
g_data_section_html     varchar2(32767) := null; -- for data section

function clean_out_editor_tag (
    p_string        in clob)
    return clob;

procedure show_breadcrumbs (
    p_application_id       in number,
    p_page_id              in number,
    p_security_group_id    in number,
    p_app_session          in number,
    p_image_prefix         in varchar2 default null,
    p_parent_entry         in varchar2 default null,
    p_parent_entry_page_id in number default null,
    p_current_entry        in varchar2 default null);

procedure show_annotations_meu;

procedure show_attachments (
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure show_attachment_examples (
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure show_recent_files (
    p_security_group_id in number,
    p_ws_app_id         in number,
    p_webpage_id        in number,
    p_max_files_to_show in number default 20);

procedure show_notes (
	p_session     in number,
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure show_tags (
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure show_tag_clouds (
    p_ws_app_id             in number,
    p_session_id            in number,
    p_alpha                 in number default 1,
    p_max                   in number default 100,
    p_limit                 in number default 10000,
    p_link_to_page          in varchar2 default '904',
    p_tag_item_filter       in varchar2 default 'IRC_TAG',
    p_clear_cache           in varchar2 default '904,RIR') ;

procedure show (
    p_ws_app_id   in number,
    p_webpage_id  in number,
    p_request     in varchar2 default null);

procedure get_last_updated_page (
    p_ws_app_id        in number,
    p_webpage_id       in number,
    p_last_updated_on  out date,
    p_last_updated_by  out varchar2);

procedure get_last_updated_file (
    p_ws_app_id        in number,
    p_webpage_id       in number,
    p_filename         out varchar2,
    p_last_updated_on  out date,
    p_last_updated_by  out varchar2);

function get_login_url(
	p_ws_app_id  in number,
	p_ws_page_id in number default null )
return varchar2;

end wwv_flow_ws_webpage;
/

