create package wwv_flow_ws_geocode
as

function get_geocode (
    p_worksheet_id  in varchar2,
    p_address       in varchar2
    ) return varchar2;

procedure cache_geocode (
    p_address   in varchar2,
    p_geocode   in varchar2
    );

procedure save_geocodes (
    p_worksheet_id  in varchar2,
    p_columns       in varchar2
    );

procedure reset_geocodes (
    p_worksheet_id  in varchar
    );

end wwv_flow_ws_geocode;
/

