create trigger WWV_FLOW_STANDARD_ICONS_T1
    before insert or update
    on WWV_FLOW_STANDARD_ICONS
    for each row
begin
    if inserting and :new.id is null then
         :new.id := wwv_flow_id.next_val;
    end if;
end;
/

