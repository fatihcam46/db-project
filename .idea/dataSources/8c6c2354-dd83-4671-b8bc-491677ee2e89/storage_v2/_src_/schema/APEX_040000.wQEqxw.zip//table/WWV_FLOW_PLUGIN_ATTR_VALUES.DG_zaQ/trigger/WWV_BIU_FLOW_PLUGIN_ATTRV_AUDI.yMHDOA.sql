create trigger WWV_BIU_FLOW_PLUGIN_ATTRV_AUDI
    before insert or update or delete
    on WWV_FLOW_PLUGIN_ATTR_VALUES
    for each row
declare
    l_action varchar2(1);
begin
    l_action := case
                  when inserting then 'I'
                  when updating  then 'U'
                  else                'D'
                end;
    begin
        wwv_flow_audit.audit_action (
           p_table_name  => 'WWV_FLOW_PLUGIN_ATTR_VALUES',
           p_action      => l_action,
           p_table_pk    => nvl(:old.id, :new.id),
           p_object_name => nvl(:new.display_value,:old.display_value) );
    exception when others then null;
    end;
end;
/

