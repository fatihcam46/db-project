create view APEX_APPLICATION_PAGE_REGIONS as
select
    w.short_name                         workspace,
    p.flow_id                            application_id,
    f.name                               application_name,
    p.id                                 page_id,
    p.name                               page_name,
    --
    r.plug_name                          region_name,
    r.parent_plug_id                     parent_region_id,
    case
      when r.parent_plug_id is not null then
          ( select region_name
              from wwv_flow_page_plugs
             where id = r.parent_plug_id )
    end                                  parent_region_name,
    nvl(decode(nvl(r.PLUG_TEMPLATE,0),0,
     'No Template',
     (select PAGE_PLUG_TEMPLATE_NAME
     from wwv_flow_page_plug_templates
     where id = r.PLUG_TEMPLATE)),'No Template') template,
    r.PLUG_TEMPLATE                      template_id,
    r.region_name                        static_id,
    decode(nvl(r.rest_enabled,'N'),'Y','Yes','No') rest_enabled,
    r.PLUG_DISPLAY_SEQUENCE              display_sequence,
    decode(nvl(r.INCLUDE_IN_REG_DISP_SEL_YN,'N'),
        'Y','Yes','N','No',r.INCLUDE_IN_REG_DISP_SEL_YN)
                                         display_region_selector,
    r.REGION_ATTRIBUTES_SUBSTITUTION     REGION_ATTRIBUTES_SUBSTITUTION,
    r.PLUG_DISPLAY_COLUMN                display_column,
    decode(r.PLUG_DISPLAY_POINT,
       'AFTER_HEADER',       'After Header',
       'BEFORE_BOX_BODY',    'Page Template Body (1. items below region content)',
       'BEFORE_SHOW_ITEMS',  'Page Template Body (2. items below region content)',
       'AFTER_SHOW_ITEMS',   'Page Template Body (3. items above region content)',
       'BEFORE_FOOTER',      'Before Footer',
       'REGION_POSITION_01', 'Page Template Region Position 1',
       'REGION_POSITION_02', 'Page Template Region Position 2',
       'REGION_POSITION_03', 'Page Template Region Position 3',
       'REGION_POSITION_04', 'Page Template Region Position 4',
       'REGION_POSITION_05', 'Page Template Region Position 5',
       'REGION_POSITION_06', 'Page Template Region Position 6',
       'REGION_POSITION_07', 'Page Template Region Position 7',
       'REGION_POSITION_08', 'Page Template Region Position 8',
       r.PLUG_DISPLAY_POINT)
                                         display_position,
    r.plug_display_point                 display_position_code,
    --
    r.PLUG_SOURCE                        region_source,
    (select name
    from   wwv_flow_menu_templates
    where  id = to_char(r.MENU_TEMPLATE_ID)
    and    flow_id = f.id)                 breadcrumb_template,
    r.MENU_TEMPLATE_ID                     breadcrumb_template_id,
    --
    (select list_template_name
    from wwv_flow_list_templates
    where id = r.LIST_TEMPLATE_ID)         list_template_override,
    r.LIST_TEMPLATE_ID                     list_template_override_id,
    --
    case r.plug_source_type
      when 'PLSQL_PROCEDURE'              then 'PL/SQL'
      when 'SIMPLE_CHART'                 then 'HTML Chart'
      when 'FLASH_CHART'                  then 'Flash Chart'
      when 'FLASH_CHART5'                 then 'Flash Chart'
      when 'FLASH_MAP'                    then 'Map'
      when 'SQL_QUERY'                    then 'Report'
      when 'DYNAMIC_QUERY'                then 'Interactive Report'
      when 'STATIC_TEXT'                  then 'HTML/Text'
      when 'STATIC_TEXT_ESCAPE_SC'        then 'HTML/Text (escape special characters)'
      when 'STATIC_TEXT_WITH_SHORTCUTS'   then 'HTML/Text (with shortcuts)'
      when 'STRUCTURED_QUERY'             then 'Report'
      when 'FUNCTION_RETURNING_SQL_QUERY' then 'Report'
      when 'SVG_CHART'                    then 'SVG Chart'
      when 'TREE'                         then 'Tree'
      when 'UPDATABLE_SQL_QUERY'          then 'Tabular Form'
      when 'URL'                          then 'URL'
      when 'REGION_DISPLAY_SELECTOR'      then 'Region Display Selector'
      when 'CALENDAR'                     then 'Calendar'
      when 'EASY_CALENDAR'                then 'Easy Calendar'
      when 'JSTREE'                       then 'JavaScript Tree'
      when 'HELP_TEXT'                    then 'Help Text'
      else
          case
            when r.plug_source_type like 'NATIVE\_%' escape '\' then
                ( select display_name from wwv_flow_plugins where flow_id = 4411 and plugin_type = 'REGION TYPE' and name = substr(r.plug_source_type, 8) )
            when r.plug_source_type like 'PLUGIN\_%' escape '\' then
                ( select display_name from wwv_flow_plugins where flow_id = r.flow_id and plugin_type = 'REGION TYPE' and name = substr(r.plug_source_type, 8) )
            when substr(r.PLUG_SOURCE_TYPE,1,1) = 'M' then 'Breadcrumb'
            else 'List'
          end
      end                                source_type,
    r.plug_source_type                   source_type_code,
    --
    r.PLUG_DISPLAY_ERROR_MESSAGE         on_error_message,
    --
    decode(substr(r.PLUG_REQUIRED_ROLE,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(r.PLUG_REQUIRED_ROLE,'!')
     and    flow_id = f.id),
     r.PLUG_REQUIRED_ROLE)               authorization_scheme,
    r.PLUG_REQUIRED_ROLE                 authorization_scheme_id,
    nvl((select r from apex_standard_conditions where d = r.PLUG_DISPLAY_CONDITION_TYPE),r.PLUG_DISPLAY_CONDITION_TYPE)
                                         condition_type,
    r.PLUG_DISPLAY_WHEN_CONDITION        condition_expression1,
    r.PLUG_DISPLAY_WHEN_COND2            condition_expression2,
    --
    r.PLUG_HEADER                        region_header_text,
    r.PLUG_FOOTER                        region_footer_text,
    (select row_template_name from wwv_flow_row_templates where id = r.PLUG_QUERY_ROW_TEMPLATE)
                                         report_template,
    r.PLUG_QUERY_ROW_TEMPLATE            report_template_id,
    r.PLUG_QUERY_HEADINGS                report_column_headings,
    r.PLUG_QUERY_HEADINGS_TYPE           headings_type,
    r.PLUG_QUERY_NUM_ROWS                maximum_rows_to_query,
    decode(r.PLUG_QUERY_NUM_ROWS_TYPE,
       'ROWS_X_TO_Y_OF_Z','Row Ranges X to Y of Z (no pagination)',
       'ROWS_X_TO_Y','Row Ranges X to Y (no pagination)',
       'SEARCH_ENGINE','Search Engine 1,2,3,4 (set based pagination)',
       'COMPUTED_BUT_NOT_DISPLAYED','Use Externally Created Pagination Buttons',
       'ROW_RANGES','Row Ranges 1-15 16-30 (with set pagination)',
       'ROW_RANGES_IN_SELECT_LIST','Row Ranges 1-15 16-30 in select list (with pagination)',
       'ROW_RANGES_WITH_LINKS','Row Ranges X to Y of Z (with pagination)',
       'NEXT_PREVIOUS_LINKS','Row Ranges X to Y (with next and previous links)',
       r.PLUG_QUERY_NUM_ROWS_TYPE)       pagination_scheme,
    decode(r.PAGINATION_DISPLAY_POSITION,
      'BOTTOM_LEFT','Bottom - Left',
      'BOTTOM_RIGHT','Bottom - Right',
      'TOP_LEFT','Top - Left',
      'TOP_RIGHT','Top - Right',
      'TOP_AND_BOTTOM_LEFT','Top and Bottom - Left',
      'TOP_AND_BOTTOM_RIGHT','Top and Bottom - Right',
      r.PAGINATION_DISPLAY_POSITION)     pagination_display_position,
    decode(r.ajax_enabled,'Y','Yes','N','No',r.ajax_enabled) ajax_enabled,
    r.PLUG_QUERY_NUM_ROWS_ITEM           number_of_rows_item,
    r.PLUG_QUERY_NO_DATA_FOUND           no_data_found_message,
    r.PLUG_QUERY_MORE_DATA               more_data_found_message,
    r.PLUG_QUERY_ROW_COUNT_MAX           maximum_row_count,
    --r.PLUG_QUERY_FORMAT_OUT              query_format_out,
    r.PLUG_QUERY_SHOW_NULLS_AS           report_null_values_as,
    --r.PLUG_QUERY_COL_ALLIGNMENTS         ,
    r.PLUG_QUERY_BREAK_COLS              breaks,
    --r.PLUG_QUERY_SUM_COLS                ,
    --r.PLUG_QUERY_NUMBER_FORMATS          ,
    --r.PLUG_QUERY_TABLE_BORDER            ,
    --r.PLUG_QUERY_HIT_HIGHLIGHTING        ,
    r.PLUG_QUERY_ASC_IMAGE               ascending_image,
    r.PLUG_QUERY_ASC_IMAGE_ATTR          ascending_image_attributes,
    r.PLUG_QUERY_DESC_IMAGE              descending_image,
    r.PLUG_QUERY_DESC_IMAGE_ATTR         descending_image_attributes,
    r.PLUG_QUERY_EXP_FILENAME            filename,
    r.PLUG_QUERY_EXP_SEPARATOR           separator,
    r.PLUG_QUERY_EXP_ENCLOSED_BY         enclosed_by,
    decode(r.PLUG_QUERY_STRIP_HTML,
      'Y','Yes',
      'N','No',
      r.PLUG_QUERY_STRIP_HTML)           strip_html,
    r.PLUG_QUERY_OPTIONS                 report_column_source_type,
    r.PLUG_QUERY_MAX_COLUMNS             max_dynamic_report_cols,
    r.PLUG_COLUMN_WIDTH                  HTML_table_cell_attributes,
    decode(r.PLUG_CUSTOMIZED,
       null,'None',
       '2','Customizable and Not Shown By Default',
       '1','Customizable and Shown By Default',
       '0','Not Customizable By End Users',
       r.PLUG_CUSTOMIZED)                 customization,
    r.PLUG_CUSTOMIZED_NAME                customization_name,
    --r.PLUG_OVERRIDE_REG_POS              ,
    (select case when r.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from wwv_flow_patches
     where id=abs(r.REQUIRED_PATCH) )         build_option,
    r.required_patch                     build_option_id,
    --
    --r.PLUG_URL_TEXT_BEGIN                ,
    --r.PLUG_URL_TEXT_END                  ,
    --
    -- region caching
    --
    nvl(decode(r.PLUG_CACHING,
    'CACHED','Cached',
    'CACHED_BY_USER','Cached by User',
    'NOT_CACHED','Not Cached',
    null,'Not Cached'),'Not Cached')     region_caching,
    --r.PLUG_CACHING_SESSION_STATE         ,
    r.PLUG_CACHING_MAX_AGE_IN_SEC        timeout_cache_after,
    r.PLUG_CACHE_WHEN                    cache_when,
    r.PLUG_CACHE_EXPRESSION1             cache_when_expression_1,
    r.PLUG_CACHE_EXPRESSION2             cache_when_expression_2,
    --r.PLUG_IGNORE_PAGINATION             ,
    --r.PLUG_CHART_FONT_SIZE               ,
    --r.PLUG_CHART_MAX_ROWS                ,
    --r.PLUG_CHART_NUM_MASK                ,
    --r.PLUG_CHART_SCALE                   ,
    --r.PLUG_CHART_AXIS                    ,
    --r.PLUG_CHART_SHOW_SUMMARY            ,
    r.REPORT_TOTAL_TEXT_FORMAT           sum_display_text,
    r.BREAK_COLUMN_TEXT_FORMAT           break_display_text,
    r.BREAK_BEFORE_ROW                   before_break_display_text,
    r.BREAK_GENERIC_COLUMN               break_column_display_text,
    r.BREAK_AFTER_ROW                    after_break_display_text,
    decode(
       r.BREAK_TYPE_FLAG,
       'REPEAT_HEADINGS_ON_BREAK_1','Repeat Headings on Break',
       'DEFAULT_BREAK_FORMATTING','Default Break Formatting',
       r.BREAK_TYPE_FLAG)                break_display_flag,
    r.BREAK_REPEAT_HEADING_FORMAT        repeat_heading_break_format,
    decode(r.CSV_OUTPUT,
    'Y','Yes','N','No',r.CSV_OUTPUT)     enable_csv_output,
    r.CSV_OUTPUT_LINK_TEXT               csv_link_label,
    r.PRINT_URL                          URL,
    r.PRINT_URL_LABEL                    link_label,
    decode(r.TRANSLATE_TITLE,
    'Y','Yes','N','No','Yes')            translate_region_title,
    --
    r.attribute_01,
    r.attribute_02,
    r.attribute_03,
    r.attribute_04,
    r.attribute_05,
    r.attribute_06,
    r.attribute_07,
    r.attribute_08,
    r.attribute_09,
    r.attribute_10,
    --
    r.LAST_UPDATED_BY                    last_updated_by,
    r.LAST_UPDATED_ON                    last_updated_on,
    r.PLUG_COMMENT                       component_comment,
    r.id                                 region_id,
    --
    (select count(*) from wwv_flow_step_items where r.id = ITEM_PLUG_ID and r.flow_id = flow_id and nvl(display_as,'x') != 'BUTTON') items,
    ((select count(*) from wwv_flow_step_items where r.id = ITEM_PLUG_ID and r.flow_id = flow_id and nvl(display_as,'x') = 'BUTTON') +
     (select count(*) from wwv_flow_step_buttons where r.id = button_plug_id and r.flow_id = flow_id)) buttons,
     --
     region_name||'.'||
     lpad(r.plug_display_sequence,5,'00000')
     ||',c='||r.PLUG_DISPLAY_column
     ||',temp='||nvl(decode(nvl(r.PLUG_TEMPLATE,0),0,'No Template',(select PAGE_PLUG_TEMPLATE_NAME from wwv_flow_page_plug_templates where id = r.PLUG_TEMPLATE)),'No Template')
     ||',pos='||decode(r.PLUG_DISPLAY_POINT,
       'AFTER_HEADER',       'After Header',
       'BEFORE_BOX_BODY',    'Page Template Body (1. items below region content)',
       'BEFORE_SHOW_ITEMS',  'Page Template Body (2. items below region content)',
       'AFTER_SHOW_ITEMS',   'Page Template Body (3. items above region content)',
       'BEFORE_FOOTER',      'Before Footer',
       'REGION_POSITION_01', 'Page Template Region Position 1',
       'REGION_POSITION_02', 'Page Template Region Position 2',
       'REGION_POSITION_03', 'Page Template Region Position 3',
       'REGION_POSITION_04', 'Page Template Region Position 4',
       'REGION_POSITION_05', 'Page Template Region Position 5',
       'REGION_POSITION_06', 'Page Template Region Position 6',
       'REGION_POSITION_07', 'Page Template Region Position 7',
       'REGION_POSITION_08', 'Page Template Region Position 8',
       r.PLUG_DISPLAY_POINT)
     ||',src='||decode(translate(dbms_lob.substr(r.PLUG_SOURCE,1,1),'M0123456789.','000000000000'),'0','Ref',dbms_lob.substr(r.PLUG_SOURCE,30,1)||'.'||dbms_lob.getlength(r.PLUG_SOURCE))
     ||(select ',bo='||PATCH_NAME b from wwv_flow_patches where id=abs(r.REQUIRED_PATCH))
     ||decode(r.PLUG_DISPLAY_ERROR_MESSAGE,null,null,',ErrMsg='||length(r.PLUG_DISPLAY_ERROR_MESSAGE))
     ||nvl((select ',auth='||name n from wwv_flow_security_schemes where to_char(id) = ltrim(r.PLUG_REQUIRED_ROLE,'!') and flow_id = f.id),r.PLUG_REQUIRED_ROLE)
     ||decode(r.PAGINATION_DISPLAY_POSITION,
      'BOTTOM_LEFT','Bottom-L',
      'BOTTOM_RIGHT','Bottom-R',
      'TOP_LEFT','Top-L',
      'TOP_RIGHT','Top-R',
      'TOP_AND_BOTTOM_LEFT','Top+Bottom-L',
      'TOP_AND_BOTTOM_RIGHT','Top+Bottom-R',
      r.PAGINATION_DISPLAY_POSITION)
      ||r.PLUG_QUERY_NUM_ROWS_TYPE
      ||r.PLUG_DISPLAY_CONDITION_TYPE
      ||substr(r.PLUG_DISPLAY_WHEN_CONDITION,1,20)||'.'||length(r.PLUG_DISPLAY_WHEN_CONDITION)
      ||substr(r.PLUG_DISPLAY_WHEN_COND2,1,20)||'.'||length(r.PLUG_DISPLAY_WHEN_COND2)
      ||decode(
       r.BREAK_TYPE_FLAG,
       'REPEAT_HEADINGS_ON_BREAK_1','RepHead on Br',
       'DEFAULT_BREAK_FORMATTING','DefBreakFor',
       r.BREAK_TYPE_FLAG)
      ||decode(r.CSV_OUTPUT,'Y','Yes','N','No',r.CSV_OUTPUT)
      ||(select ',rtmp='||row_template_name t from wwv_flow_row_templates where id = r.PLUG_QUERY_ROW_TEMPLATE)
      ||decode(r.PLUG_QUERY_NUM_ROWS,null,null,'mr='||r.PLUG_QUERY_NUM_ROWS)
      ||r.BREAK_REPEAT_HEADING_FORMAT
      ||r.CSV_OUTPUT_LINK_TEXT
      ||substr(r.PRINT_URL,1,10)||length(r.PRINT_URL)
      ||length(PRINT_URL_LABEL)
      ||decode(r.TRANSLATE_TITLE,'Y','Yes','N','No','Yes')||
      length(PLUG_HEADER)||length(PLUG_FOOTER)
      ||r.PLUG_CUSTOMIZED
      ||length(r.PLUG_COLUMN_WIDTH)
      ||substr(r.region_name,1,15)
      ||length(REGION_ATTRIBUTES_SUBSTITUTION)
     component_signature,
     decode(rtrim(translate(r.plug_source_type,'01234567890','0000000000'),'0'),null,to_number(r.plug_source_type),null) list_id
from wwv_flow_page_plugs r,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.id = p.flow_id and
      f.id = r.flow_id and
      p.id = r.page_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_REGIONS is 'Identifies a content container associated with a Page and displayed within a position defined by the Page Template'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.PAGE_ID is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REGION_NAME is 'Identifies the Region Name.  The display of the region name is controlled by the Region Template substitution string TITLE.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.PARENT_REGION_ID is 'Identifies the region id of the parent region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.PARENT_REGION_NAME is 'Identifies the parent region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.TEMPLATE is 'Identifies the template used to display the region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.TEMPLATE_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.STATIC_ID is 'Reference this value using the substitution string #REGION_STATIC_ID#'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REST_ENABLED is 'Identifies whether the region can be accessed via a RESTful call'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.DISPLAY_SEQUENCE is 'Identifies the Display Sequence of the Region within each Display Position'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REGION_ATTRIBUTES_SUBSTITUTION is 'Identifies text to be substituted by the region template #REGION_ATTRIBUTES# substituion string'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.DISPLAY_COLUMN is 'Identifies the column used to display the region, allows regions to be positioned in a second column within a single Display Position.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.DISPLAY_POSITION is 'Identifies the position within the Page Template that the Region will be displayed'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.DISPLAY_POSITION_CODE is 'Identifies the coded value of the position within the Page Template that the Region will be displayed'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REGION_SOURCE is 'Identifies the source of the region, reference Region Source Type'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BREADCRUMB_TEMPLATE is 'Identifies breadcrumb template'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BREADCRUMB_TEMPLATE_ID is 'Identifies breadcrumb template ID'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.LIST_TEMPLATE_OVERRIDE is 'Identifies the List Template to be used to display regions of type List.  By default the List Template is defined in the List definition, if a value is specified in this attribute, this template will be used to render the List.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.LIST_TEMPLATE_OVERRIDE_ID is 'Foreign key of list template override'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.SOURCE_TYPE is 'Identifies how APEX will interpret the Region Source'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.SOURCE_TYPE_CODE is 'Internal code of SOURCE_TYPE'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ON_ERROR_MESSAGE is 'Identifies the error text to be displayed when the display of a region results in an error'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this component to be displayed'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CONDITION_TYPE is 'Identifies the condition type used to conditionally display the region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REPORT_TEMPLATE is 'Report templates provide control over the results of a row from your SQL query'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REPORT_TEMPLATE_ID is 'Identifies report template ID'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REPORT_COLUMN_HEADINGS is 'Report column heading override, can be used to define dynamic report column headings'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.HEADINGS_TYPE is 'Identifies the how report column headings are computed'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.MAXIMUM_ROWS_TO_QUERY is 'Specifies the maximum rows that can be retuned by a given query.  Avoids attempting to send millions of rows to a web browser.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.PAGINATION_SCHEME is 'Pagination provides the user with information about the number of rows and the current position within the result set. Pagination also defines the style of links or buttons that are used to navigate to the next or previous page.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.PAGINATION_DISPLAY_POSITION is 'Pagination can be displayed on the left side, right side, at the bottom, or above the report.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.AJAX_ENABLED is 'Specifies if the region is ajax enabled.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.NUMBER_OF_ROWS_ITEM is 'Defines the maximum number of rows to display per page.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.NO_DATA_FOUND_MESSAGE is 'Defines the text message that displays when the query does not return any rows.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.MORE_DATA_FOUND_MESSAGE is 'Defines the text message that displays when more rows exist.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.MAXIMUM_ROW_COUNT is 'Defines the maximum number of rows to query, relevant for pagination schemes which display "Rows X - Y of Z".  Counting fewer rows can improve performance and counting thousands of rows can degrade performance.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REPORT_NULL_VALUES_AS is 'Identifies the text to display for null columns. The default value is "(null)".'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BREAKS is 'Identifies how breaks should be formatted.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ASCENDING_IMAGE is 'Defines the image shown in report headings to sort column values in ascending order.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ASCENDING_IMAGE_ATTRIBUTES is 'Image attributes for sort images used to define attributes such width and height of image.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.DESCENDING_IMAGE is 'Defines the image shown in report headings to sort column values in descending order.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.DESCENDING_IMAGE_ATTRIBUTES is 'Image attributes for sort images used to define attributes such width and height of image.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.FILENAME is 'Specify a name for the export file. If no name is specified, the region name is used followed by the extension .csv.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.SEPARATOR is 'Identifies a column separator. If no value is entered, a comma or semicolon is used depending on your current NLS settings.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ENCLOSED_BY is 'Identifies a delimiter character. This character is used to delineate the starting and ending boundary of a data value. Default delimiter is double quotes.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.STRIP_HTML is 'Specifies whether or not to remove HTML tags from the original column values for HTML expressions, column links and report data exported as CSV files.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REPORT_COLUMN_SOURCE_TYPE is 'Determines how report columns will be computed, values include DERIVED_REPORT_COLUMNS and GENERIC_REPORT_COLUMNS'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.MAX_DYNAMIC_REPORT_COLS is 'Maximum number of dynamic report columns'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.HTML_TABLE_CELL_ATTRIBUTES is 'When generating HTML to display items use these HTML table cell attributes'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CUSTOMIZATION is 'Identifies level of customization support for this page region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CUSTOMIZATION_NAME is 'Name of region to show in popup customization window'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BUILD_OPTION is 'Region will be displayed if the Build Option is enabled'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BUILD_OPTION_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REGION_CACHING is 'Identifies caching method'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.TIMEOUT_CACHE_AFTER is 'Identify how long a cached region will remain valid in seconds'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CACHE_WHEN is 'Identifies a condition must be true for the region to be cached or to render from cache'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CACHE_WHEN_EXPRESSION_1 is 'Identifies expression corresponding to Cache When condition'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CACHE_WHEN_EXPRESSION_2 is 'Identifies expression corresponding to Cache When condition'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.SUM_DISPLAY_TEXT is 'Display this text when printing report sums'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BREAK_DISPLAY_TEXT is 'Text displayed on control breaks'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BEFORE_BREAK_DISPLAY_TEXT is 'Defines the text that displays before break columns when displaying a break row.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BREAK_COLUMN_DISPLAY_TEXT is 'Defines the column template to use when displaying a column break. Use #COLUMN_VALUE# substitutions.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.AFTER_BREAK_DISPLAY_TEXT is 'Defines the text that displays after break columns when displaying a break row.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BREAK_DISPLAY_FLAG is 'Identify how you would like your breaks to be displayed'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REPEAT_HEADING_BREAK_FORMAT is 'Defines the heading template for repeating headings on column 1. Use #COLUMN_VALUE# substitutions.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ENABLE_CSV_OUTPUT is 'Enables the query results to be spooled to a CSV file. To enable this option, you must use a report template with a #CSV_LINK# substitution string and set this option to YES.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.CSV_LINK_LABEL is 'Specifies the text for the link which will invoke the CSV download.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.URL is 'Specifies the URL to a server for post processing of a report. See documentation for instructions.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.LINK_LABEL is 'Specifies the text for the link which will invoke the external processing engine.'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.TRANSLATE_REGION_TITLE is 'Identifies if this region title should be a candidate for translation or not (Yes or No)'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_01 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_02 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_03 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_04 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_05 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_06 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_07 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_08 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_09 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ATTRIBUTE_10 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.REGION_ID is 'Primary Key of this Region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.ITEMS is 'Count of Items corresponding to this region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.BUTTONS is 'Count of Buttons corresponding to this region'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

comment on column APEX_APPLICATION_PAGE_REGIONS.LIST_ID is 'Associated list, if region is of type list.  Can be joined to APEX_APPLICATION_LISTS.'
/

