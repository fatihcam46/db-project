create trigger WWV_BIU_FLOW_RPT_LAYOUTS_AUDIT
    before insert or update or delete
    on WWV_FLOW_REPORT_LAYOUTS
    for each row
declare
    l_action varchar2(1);
begin
    l_action := case
                  when inserting then 'I'
                  when updating  then 'U'
                  else                'D'
                end;
    begin
        wwv_flow_audit.audit_action (
           p_table_name => 'WWV_FLOW_REPORT_LAYOUTS',
           p_action     => l_action,
           p_table_pk   => nvl(:old.id, :new.id),
           p_object_name => nvl(:new.report_layout_name,:old.report_layout_name) );
    exception when others then null;
    end;
end;
/

