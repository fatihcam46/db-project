create view WWV_FLOW_AUTHORIZED as
select w.short_name              as workspace,
       w.provisioning_company_id as workspace_id,
       f.id                      as application_id,
       f.name                    as application_name
  from ( select nvl(nv('FLOW_SECURITY_GROUP_ID'), 0) sgid from dual ) d,
       wwv_flow_company_schemas s,
       wwv_flow_companies w,
       wwv_flows f
 where (  s.schema = user
       or user in ('SYS','SYSTEM', 'APEX_040000')
       or s.security_group_id = d.sgid )
   and w.provisioning_company_id =  s.security_group_id
   and w.provisioning_company_id != 0
   and f.security_group_id       =  w.provisioning_company_id
   and f.owner                   =  s.schema
   and (  d.sgid != 0
       or nvl(f.build_status, 'x') != 'RUN_ONLY')
/

