create package wwv_flow_ws_api
as

g_canonical_date_format varchar2(100) := 'RRRR-MM-DD"T"hh24:mi:ss';
g_canonical_ts_format   varchar2(100) := 'RRRR-MM-DD"T"hh24:mi:ss.xff';
g_dml_date_format       varchar2(100) := 'YYYYMMDDHH24MISS';

g_edit_row_collection_name  varchar2(255) := 'APEX$_WS_ROWS_EDIT_ROW';

empty_vc_arr wwv_flow_global.vc_arr2;
type col_val_arr_t is table of varchar2(32767) index by varchar2(32767);
type col_arr is table of col_val_arr_t index by binary_integer;
g_column_change_in_progress  boolean := false;

function is_app_home_page (
    p_ws_app_id    in number,
    p_webpage_id   in number)
    return boolean;

function get_logo (
	p_ws_app_id         in number,
	p_security_group_id in number)
	return varchar2;

function get_dbms_sql_cursor(
    p_query  in varchar2,
    p_values in wwv_flow_global.vc_arr2 default empty_vc_arr)
    return integer;

function alias_exists (
    p_ws_app_id    in number,
    p_alias        in varchar2,
    p_alias_type   in varchar2,
    p_worksheet_id in number default null,
    p_page_id      in number default null) return boolean;

function annotation_exists (
    p_ws_app_id      in number) return boolean;

function page_annotation_exists (
    p_ws_app_id       in number,
    p_webpage_id      in number,
    p_annotation_type in varchar2) return boolean;

function get_next_webpg_section_seq (
    p_webpage_id       in number)  return number;

function get_utilization_num (
    p_workspace_id     in number default null,
    p_type             in varchar2 default null) return number;

function get_data_grid_id (
    p_worksheet_id     in number) return number;

function get_ws_app_id (
    p_worksheet_id      in number) return number;

function get_websheet_name (
    p_worksheet_id     in number) return varchar2;

function websheet_name_exists (
    p_ws_app_id     in number,
    p_name          in varchar2,
    p_type          in varchar2 default 'DATA') return boolean;

function get_item_value (
    p_item_name in varchar2
    ) return varchar2;

function get_condition_display (
    p_column_name       in varchar2 default null,
    p_column_label      in varchar2 default null,
    p_operator          in varchar2 default null,
    p_expr              in varchar2 default null,
    p_expr2             in varchar2 default null,
    p_condition_display in varchar2 default null) return varchar2;

procedure run_query (
    p_sql        in varchar2,
    p_values     in wwv_flow_global.vc_arr2 default empty_vc_arr,
    p_max_row    in number default null,
    p_col_vals   out col_arr);

procedure save_checked (
        p_worksheet_id   in number);

procedure delete_rows (
    p_websheet_id      in number,
    p_rows             in varchar2 default 'SELECTED',
    p_selected_rows    in varchar2 default null,
    p_confirm          in varchar2 default null,
    p_validation_error out varchar2);

procedure delete_row (
    p_websheet_id   in number,
    p_row_id        in number);

procedure process_row (
        p_ws_app_id         in  number,
        p_worksheet_id      in  number,
        p_websheet_id       in  number,
        p_row_id            in  number,
        f01                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f02                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f03                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f04                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f05                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f06                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f07                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f08                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f09                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f10                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f11                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f12                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f13                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f14                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f15                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f16                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f17                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f18                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f19                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f20                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f21                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f22                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f23                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f24                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f25                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f26                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f27                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f28                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f29                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f30                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f31                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f32                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f33                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f34                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f35                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f36                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f37                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f38                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f39                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f40                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f41                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f42                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f43                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f44                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f45                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f46                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f47                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f48                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f49                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        f50                 in  wwv_flow_global.vc_arr2 default empty_vc_arr,
        p_validation_error  out varchar2,
        p_validation_count  out number,
        p_ajax_mode         in  boolean                 default false );

----------
-- Sharing
--
procedure share_ws_with_individuals (
        p_worksheet_id in number,
        p_person_list in varchar2,
        p_allow_select in varchar2,
        p_allow_insert in varchar2,
        p_allow_update in varchar2,
        p_allow_delete in varchar2);

--
-- inline updates
--
procedure update_cell (
    p_worksheet_id     in number,
    p_websheet_id      in number,
    p_row_id           in number,
    p_column_name      in varchar2,
    p_new_value        in varchar2 default null,
    p_change_count     in number default null,
    p_validation_error out varchar2);

procedure save_websheet_properties (
    p_ws_app_id        in number,
    p_worksheet_id     in number,
    p_name             in varchar2 default null,
    p_alias            in varchar2 default null,
    p_description      in varchar2 default null,
    p_row_pk1          in varchar2 default null,
    p_row_pk2          in varchar2 default null,
    p_row_pk3          in varchar2 default null,
    p_publish          in varchar2 default null,
    p_validation_error out varchar2
    );

procedure save_column_properties (
    p_worksheet_id      in number,
    p_websheet_id       in number,
    p_db_column_name    in varchar2 default null,
    p_display_order     in varchar2 default null,
    p_group_id          in number default null,
    p_display_as        in varchar2 default null,
    p_lov_id            in varchar2 default null,
    p_lov_name          in varchar2 default null,
    p_lov_entries       in varchar2 default null,
    p_label             in varchar2 default null,
    p_format_mask       in varchar2 default null,
    p_value_required    in varchar2 default null,
    p_heading_alignment in varchar2 default null,
    p_column_alignment  in varchar2 default null,
    p_default_type      in varchar2 default null,
    p_default_text      in varchar2 default null,
    p_width             in number default null,
    p_max_width         in number default null,
    p_height            in number default null,
    p_help_text         in varchar2 default null,
    p_validation_error  out varchar2
    );

procedure add_column (
    p_worksheet_id     in number,
    p_websheet_id      in number,
    p_report_id        in number default null,
    p_column_name      in varchar2 default null,
    p_column_type      in varchar2 default null,
    p_display_as       in varchar2 default null,
    p_lov_id           in varchar2 default null,
    p_lov_name         in varchar2 default null,
    p_lov_entries      in varchar2 default null,
    p_value_required   in varchar2 default null,
    p_default_type     in varchar2 default null,
    p_default_text     in varchar2 default null,
    p_validation_error out varchar2
    );

procedure remove_column (
    p_worksheet_id     in number,
    p_columns          in varchar2 default null,
    p_confirm          in varchar2 default null,
    p_validation_error out varchar2
    );

procedure delete_lov (
    p_worksheet_id     in number,
    p_lov_id           in number default null,
    p_validation_error out varchar2
    );

procedure save_lov (
    p_worksheet_id     in number,
    p_websheet_id      in number,
    p_lov_id           in number default null,
    p_lov_name         in varchar2 default null,
    p_lov_entries      in varchar2 default null,
    p_validation_error out varchar2
    );

procedure save_column_group (
    p_worksheet_id     in number,
    p_websheet_id      in number,
    p_group_id         in number default null,
    p_seq              in number default null,
    p_group_name       in varchar2 default null,
    p_description      in varchar2 default null,
    p_columns          in varchar2 default null,
    p_validation_error out varchar2
    );

procedure delete_column_group (
    p_worksheet_id     in number,
    p_group_id         in number);

procedure copy_page (
    p_ws_app_id        in number,
    p_webpage_id       in number,
    p_new_name         in varchar2 default null);

procedure copy_websheet (
    p_ws_app_id        in number,
    p_worksheet_id     in number,
    p_websheet_id      in number,
    p_new_name         in varchar2 default null,
    p_validation_error out varchar2
    );

procedure delete_websheet (
    p_worksheet_id     in number,
    p_websheet_id      in number,
    p_websheet_type    in varchar2 default 'DATA',
    p_confirm          in varchar2 default null,
    p_validation_error out varchar2);

procedure set_column_value (
    p_websheet_id      in number,
    p_db_column_name   in varchar2 default null,
    p_new_value        in varchar2 default null,
    p_rows             in varchar2 default 'SELECTED',
    p_selected_rows    in varchar2 default null,
    p_validation_error out varchar2);

procedure replace_column_value (
    p_websheet_id       in number,
    p_rows              in varchar2 default null,
    p_db_column_names   in varchar2 default null,
    p_find_what         in varchar2 default null,
    p_replace_with      in varchar2 default null,
    p_selected_rows     in varchar2 default null,
    p_validation_error  out varchar2);

procedure fill_column_value (
    p_websheet_id        in number,
    p_db_column_name     in varchar2 default null,
    p_validation_error   out varchar2);

procedure add_note (
    p_ws_app_id        in number default null,
    p_note_id          in number default null,
    p_websheet_id      in number default null,
    p_row_id           in number default null,
    p_webpage_id       in number default null,
    p_component_level  in varchar2 default null,
    p_content          in varchar2 default null);

procedure add_link (
    p_link_id          in number default null,
    p_ws_app_id        in number default null,
    p_websheet_id      in number default null,
    p_row_id           in number default null,
    p_component_level  in varchar2 default null,
    p_link_name        in varchar2 default null,
    p_url              in varchar2 default null,
    p_link_description in varchar2 default null,
    p_display_sequence in number default null,
    p_validation_error out varchar2);

procedure add_tags (
    p_ws_app_id       in number default null,
    p_webpage_id      in number default null,
    p_websheet_id     in number default null,
    p_row_id          in number default null,
    p_component_level in varchar2 default null,
    p_tag             in varchar2 default null);

procedure add_acl_entry (
    p_ws_app_id       in number default null,
    p_acl_id          in number default null,
    p_username        in varchar2 default null,
    p_priv            in varchar2 default null);

procedure delete_note (
    p_note_id   in number);

procedure delete_link (
    p_link_id in number);

procedure delete_tag (
    p_tag_id         in number,
    p_websheet_id    in number default null,
    p_row_id         in number default null
    );

procedure delete_acl_entry (
    p_acl_id         in number);

procedure get_websheet_attr (
    p_worksheet_id        in number,
    p_app_user            in varchar2 default null,
    p_base_report_id      in number default null,
    p_status              out varchar2,
    p_view_only_columns   out varchar2,
    p_username_in_columns out varchar2,
    p_parent_column       out varchar2,
    p_child_column        out varchar2);

procedure save_column_validation (
    p_ws_app_id        in number,
    p_worksheet_id     in number,
    p_websheet_id      in number default null,
    p_validation_id    in number default null,
    p_validation_level in varchar2 default null,
    p_name             in varchar2 default null,
    p_seq              in number default null,
    p_type             in varchar2 default null,
    p_expr1            in varchar2 default null,
    p_expr2            in varchar2 default null,
    p_error_message    in varchar2 default null,
    p_validation_error out varchar2
    );

procedure delete_column_validation (
    p_worksheet_id     in number,
    p_validation_id    in number default null
    );

procedure get_filtered_columns (
    p_worksheet_id  in number,
    p_group_id       in varchar2,
    p_show          in varchar2);

procedure change_column_type (
    p_worksheet_id         in number,
    p_websheet_id          in number,
    p_old_db_column_name   in varchar2,
    p_new_column_type      in varchar2,
    p_format_mask_to_use   in varchar2 default null);

procedure create_history_collection (
    p_worksheet_id  in number,
    p_websheet_id   in number,
    p_max_row_count in number default null
    );

procedure create_link_collection (
    p_ws_app_id    in number,
    p_max_row_count in number default null
    );

procedure get_link_info (
    p_ws_app_id       in number,
    p_id              in number,
    p_component_level out varchar2,
    p_webpage_id      out number,
    p_worksheet_id    out number,
    p_websheet_id     out number,
    p_row_id          out number,
    p_link_name       out varchar2,
    p_url             out varchar2,
    p_created_on      out date,
    p_created_by      out varchar2,
    p_updated_on      out date,
    p_updated_by      out varchar2
    );

procedure create_acl_collection (
    p_ws_app_id     in number,
    p_max_row_count in number default null
    );

procedure create_attachment_collection (
    p_ws_app_id     in number,
    p_max_row_count in number default null
    );

procedure create_sec_history_collection (
    p_ws_app_id     in number,
    p_webpage_id    in number default null,
    p_max_row_count in number default null
    );

procedure create_search_collection (
    p_search                in varchar2 default null,
    p_security_group_id     in number   default null,
    p_ws_app_id             in number   default null,
    p_max_row_count         in number   default null,
    p_searchable_components in varchar2 default null,
    p_app_session           in varchar2 default '0'
    );

procedure create_pg_sec_collection (
    p_security_group_id     in number   default null,
    p_ws_app_id             in number   default null,
    p_page_id               in number   default null,
    p_app_session           in varchar2 default '0'
    );

procedure create_section_collection (
    p_security_group_id     in number   default null,
    p_ws_app_id             in number   default null
    );

procedure get_attachment_info (
    p_ws_app_id        in number,
    p_id               in number,
    p_component_level  out varchar2,
    p_webpage_id       out number,
    p_worksheet_id     out number,
    p_websheet_id      out number,
    p_row_id           out number,
    p_name             out varchar2,
    p_image_alias      out varchar2,
    p_image_attributes out varchar2,
    p_description      out varchar2,
    p_created_on       out date,
    p_created_by       out varchar2,
    p_updated_on       out date,
    p_updated_by       out varchar2
    );

procedure create_note_collection (
    p_ws_app_id     in number,
    p_max_row_count in number default null
    );

procedure get_note_info (
    p_ws_app_id       in number,
    p_id              in number,
    p_component_level out varchar2,
    p_webpage_id      out number,
    p_worksheet_id    out number,
    p_websheet_id     out number,
    p_row_id          out number,
    p_note            out varchar2,
    p_created_on      out date,
    p_created_by      out varchar2,
    p_updated_on      out date,
    p_updated_by      out varchar2
    );

procedure create_tag_collection (
    p_ws_app_id     in number,
    p_max_row_count in number default null
    );

procedure get_tag_info (
    p_ws_app_id       in number,
    p_id              in number,
    p_component_level out varchar2,
    p_webpage_id      out number,
    p_worksheet_id    out number,
    p_websheet_id     out number,
    p_row_id          out number,
    p_tag             out varchar2,
    p_created_on      out date,
    p_created_by      out varchar2,
    p_updated_on      out date,
    p_updated_by      out varchar2
    );

procedure create_webpage (
    p_webpage_id      in number default null,
    p_ws_app_id       in number default null,
    p_name            in varchar2 default null,
    p_page_alias      in varchar2 default null,
    p_description     in varchar2 default null,
    p_parent_page_id  in number default null,
    p_section_title   in varchar2 default null,
    p_section_content in varchar2 default null);

procedure fetch_note (
    p_note_id     in  number,
    -- out
    p_content     out varchar2);

procedure fetch_tag (
    p_webpage_id  in number,
    --
    p_tags        out varchar2);

procedure fetch_data_section (
    p_section_id           in number,
    p_section_type         in varchar2,
    -- out
    p_display_seq          out number,
    p_title                out varchar2,
    --
    p_worksheet_id         out number,
    p_websheet_type        out varchar2,
    p_websheet_id          out number,
    p_websheet_name        out varchar2,
    p_report_id            out number,
    p_data_section_style   out number
    );

procedure fetch_chart_section (
    p_section_id           in number,
    p_section_type         in varchar2,
    -- out
    p_display_seq          out number,
    p_title                out varchar2,
    --
    p_worksheet_id         out number,
    p_websheet_type        out varchar2,
    p_websheet_id          out number,
    p_websheet_name        out varchar2,
    p_report_id            out number,
    p_report_columns       out varchar2,
    --
    p_chart_type           out varchar2,
    p_chart_3d             out varchar2,
    p_chart_label          out varchar2,
    p_label_axis_title     out varchar2,
    p_chart_value          out varchar2,
    p_value_axis_title     out varchar2,
    p_chart_aggregate      out varchar2,
    p_chart_sorting        out varchar2
    );

procedure fetch_text_section (
    p_section_id       in number,
    -- out
    p_display_seq      out number,
    p_title            out varchar2,
    p_content          out varchar2
    );

procedure fetch_nav_section (
    p_section_id           in number,
    p_section_type         in varchar2,
    -- out
    p_display_seq          out number,
    p_title                out varchar2,
    p_nav_start_webpage_id out number,
    p_nav_max_level        out number,
    p_nav_include_link     out varchar2);

procedure save_webpage_section (
    p_section_id            in number default null,
    p_ws_app_id             in number default null,
    p_webpage_id            in number default null,
    p_section_type          in varchar2 default null,
    p_display_seq           in number default null,
    p_title                 in varchar2 default null,
    p_content               in varchar2 default null,
    p_nav_start_webpage_id  in number default null,
    p_nav_max_level         in number default null,
    p_nav_include_link      in varchar2 default null,
    --
    p_data_grid_id          in number default null,
    p_report_id             in number default null,
    p_data_section_style    in number default null,
    --
    p_chart_type            in varchar2 default null,
    p_chart_3d              in varchar2 default null,
    p_chart_label           in varchar2 default null,
    p_label_axis_title      in varchar2 default null,
    p_chart_value           in varchar2 default null,
    p_value_axis_title      in varchar2 default null,
    p_chart_aggregate       in varchar2 default null,
    p_chart_sorting         in varchar2 default null
    );

procedure save_section_seq_title (
    p_section_id            in number default null,
    p_ws_app_id             in number default null,
    p_webpage_id            in number default null,
    p_display_seq           in number default null,
    p_title                 in varchar2 default null
    );

procedure delete_webpage_section (
    p_section_id       in number default null,
    p_section_type     in varchar2 default null,
    p_webpage_id       in number default null);

procedure move_section_to_new_page (
    p_ws_app_id             in number,
    p_section_id            in number,
    p_old_page_id           in number,
    p_new_page_name         in varchar2,
    p_new_page_alias        in varchar2 default null,
    p_new_parent_page_id    in number default null,
    p_new_section_sequence  in number default null
    );

procedure move_section_to_existing_page (
    p_ws_app_id             in number,
    p_section_id            in number,
    p_old_page_id           in number,
    p_new_page_id           in number,
    p_new_section_sequence  in number default null
    );

procedure display_create_ws_app_confirm(
    p_ws_app_id      in number,
    p_name           in varchar2,
    p_description    in varchar2 default null,
    p_section_title  in varchar2 default null
    );

procedure create_ws_app (
    p_ws_app_id       in number default null,
    p_name            in varchar2 default null,
    p_description     in varchar2 default null,
    p_acl_type        in varchar2 default 'DEFAULT',
    p_section_title   in varchar2 default null,
    p_section_content in varchar2 default null,
    --
    p_flow_id        in number default null
    );

procedure add_ws_page (
    p_page_type       in varchar2,
    p_page_name       in varchar2,
    p_parent_page_id  in number default null,
    p_ws_report_owner in varchar2 default null,
    p_ws_report_table in varchar2 default null);

procedure delete_webpage (
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure delete_ws_app (
    p_ws_app_id   in number);

procedure display_column_filter_lov (
    p_websheet_id      in number,
    p_db_column_name   in varchar2,
    p_value            in varchar2 default null);

procedure create_ws_report (
    p_report_id    in  number   default null,
    p_ws_app_id    in  number   default null,
    p_flow_id      in  number   default null,
    p_schema       in  varchar2 default null,
    p_source_type  in  varchar2 default null,
    p_report_name  in  varchar2 default null,
    p_report_alias in  varchar2 default null,
    p_table_name   in  varchar2 default null,
    p_query        in  varchar2 default null,
    p_worksheet_id out number,
    p_websheet_id  out number);

procedure split_ws_rpt_link_url (
    p_url               in varchar2,
    --
    p_websheet_id       out number,
    p_reset_ir          out varchar2,
    p_clear_ir          out varchar2,
    p_column1           out varchar2,
    p_operator1         out varchar2,
    p_value1            out varchar2,
    p_column2           out varchar2,
    p_operator2         out varchar2,
    p_value2            out varchar2,
    p_column3           out varchar2,
    p_operator3         out varchar2,
    p_value3            out varchar2
    );

function build_ws_rpt_link_url (
    p_ws_app_id         in number,
    p_websheet_id       in number,
    p_reset_ir          in varchar2 default null,
    p_clear_ir          in varchar2 default null,
    p_column1           in varchar2 default null,
    p_operator1         in varchar2 default null,
    p_value1            in varchar2 default null,
    p_column2           in varchar2 default null,
    p_operator2         in varchar2 default null,
    p_value2            in varchar2 default null,
    p_column3           in varchar2 default null,
    p_operator3         in varchar2 default null,
    p_value3            in varchar2 default null
    ) return varchar2;

procedure edit_ws_report_attr (
    p_worksheet_id              in number,
    p_websheet_id               in number,
    p_websheet_name             in varchar2,
    p_websheet_alias            in varchar2,
    p_max_row_count             in number default null,
    p_max_row_count_message     in varchar2 default null,
    p_no_data_found_message     in varchar2 default null,
    p_base_pk1                  in varchar2 default null,
    p_show_nulls_as             in varchar2 default null,
    p_pagination_type           in varchar2 default null,
    p_show_detail_link          in varchar2 default null,
    p_detail_link               in varchar2 default null,
    p_detail_link_text          in varchar2 default null,
    p_detail_link_attr          in varchar2 default null,
    p_allow_exclude_null_values in varchar2 default null,
    p_allow_hide_extra_columns  in varchar2 default null
    );

procedure edit_ws_rpt_column_attr (
    p_worksheet_id           in number,
    p_column_id              in number,
    p_display_text_as        in varchar2 default null,
    p_column_label           in varchar2 default null,
    p_report_label           in varchar2 default null,
    p_sync_form_label        in varchar2 default null,
    p_format_mask            in varchar2 default null,
    p_heading_alignment      in varchar2 default null,
    p_column_alignment       in varchar2 default null,
    p_allow_sorting          in varchar2 default null,
    p_allow_filtering        in varchar2 default null,
    p_allow_ctrl_breaks      in varchar2 default null,
    p_allow_aggregations     in varchar2 default null,
    p_allow_computations     in varchar2 default null,
    p_allow_charting         in varchar2 default null,
    p_allow_group_by         in varchar2 default null,
    p_allow_hide             in varchar2 default null,
    p_allow_filters          in varchar2 default null,
    p_allow_highlighting     in varchar2 default null,
    p_rpt_show_filter_lov    in varchar2 default null,
    p_rpt_lov                in varchar2 default null,
    p_column_link            in varchar2 default null,
    p_column_linktext        in varchar2 default null,
    p_column_link_attr       in varchar2 default null);

function ws_rpt_src_changed (
    p_worksheet_id    in number,
    p_websheet_id     in number,
    p_new_owner       in varchar2,
    p_new_source      in varchar2
    ) return boolean;

procedure change_ws_rpt_query (
    p_worksheet_id    in number,
    p_websheet_id     in number,
    p_new_owner       in varchar2,
    p_new_source      in varchar2 default null
    );

procedure save_ws_rpt_query (
    p_flow_id        in number,
    p_worksheet_id   in number,
    p_websheet_id    in number,
    p_owner          in varchar2 default null,
    p_query          in varchar2 default null
    );

function get_item_help (
    p_db_column_name    in varchar2,
    p_workspace_id      in number,
    p_worksheet_id      in number
    ) return varchar2;

procedure get_ws_report_attr (
    p_websheet_id  in number,
    p_name         out varchar2,
    p_alias        out varchar2);

function inline_date_picker_options(
    p_worksheet_id      in varchar,
    p_date              in varchar,
    p_column            in varchar )
return varchar2;

procedure show_page_900_footer (
    p_application_id       in number default 0,
    p_page_id              in number default 0,
    p_app_session          in number default 0
    );


function get_section_name (
	p_section_id   in number)
	return varchar2
	;

function get_page_count (
    p_ws_app_id    in number)
    return number;

function get_report_count (
    p_ws_app_id    in number)
    return number;

function get_datagrid_count (
    p_ws_app_id    in number)
    return number;

function get_file_count (
	p_ws_app_id    in number)
	return number
	;
function get_file_size (
	p_ws_app_id   in number)
	return number
	;

function get_section_count (
	p_ws_app_id   in number)
	return number;

function get_note_count (
	p_ws_app_id   in number)
	return number;

function get_tag_count (
	p_ws_app_id   in number)
	return number;

function get_datagrid_row_count (
	p_ws_app_id   in number)
	return number;

function get_acl_table
    return clob;

procedure send_page_email (
    p_ws_app_id   in number,
    p_webpage_id  in number,
    p_to          in varchar2 default null,
    p_subject     in varchar2 default null,
    p_body        in varchar2 default null
    );

procedure create_data_grid_from_cp_paste (
    p_ws_app_id         in number,
    p_name              in varchar2,
    p_alias             in varchar2 default null,
    p_headings_included in varchar2 default null,
    p_worksheet_id      out number,
    p_websheet_id       out number
    );

procedure create_data_grid_from_scratch (
    p_ws_app_id     in number,
    p_name          in varchar2,
    p_alias         in varchar2 default null,
    p_column_order  in varchar2 default null,
    p_worksheet_id  out number,
    p_websheet_id   out number
    );

end  wwv_flow_ws_api;
/

