create view APEX_APPLICATION_ITEMS as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    i.NAME                           item_name,
    --i.NAME_LENGTH
    i.DATA_TYPE                      data_type,
    --i.IS_PERSISTENT                  ,
    i.PROTECTION_LEVEL               Session_State_Protection,
    (select case when i.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(i.REQUIRED_PATCH))    build_option,
    i.LAST_UPDATED_BY                ,
    i.LAST_UPDATED_ON                ,
    i.ITEM_COMMENT                   component_comment,
    i.id                             application_item_id,
    --
    i.NAME
    ||' dt='||i.DATA_TYPE
    ||' prot='||i.PROTECTION_LEVEL
    ||' bo='||(select PATCH_NAME
     from   wwv_flow_patches
     where  id =i.REQUIRED_PATCH)
    component_signature
from wwv_flow_items i,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = i.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_ITEMS is 'Identifies Application Items used to maintain session state that are not associated with a page'
/

comment on column APEX_APPLICATION_ITEMS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_ITEMS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_ITEMS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_ITEMS.ITEM_NAME is 'Name of the Application Item used to maintain session state'
/

comment on column APEX_APPLICATION_ITEMS.DATA_TYPE is 'Datatype (Varchar or Number) of the Application Item.  Use a numeric data type to limit exposure to URL hackers for management of numeric session state'
/

comment on column APEX_APPLICATION_ITEMS.SESSION_STATE_PROTECTION is 'Identifies the Session State Protection for this item.  If the item is "Unrestricted" the item may be set by passing the item name/value in a URL or in a form.  Other protection levels provide enhanced protection of session state.'
/

comment on column APEX_APPLICATION_ITEMS.BUILD_OPTION is 'Application Item will be available if the Build Option is enabled'
/

comment on column APEX_APPLICATION_ITEMS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_ITEMS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_ITEMS.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_ITEMS.APPLICATION_ITEM_ID is 'Primary key of this Application Item'
/

comment on column APEX_APPLICATION_ITEMS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

