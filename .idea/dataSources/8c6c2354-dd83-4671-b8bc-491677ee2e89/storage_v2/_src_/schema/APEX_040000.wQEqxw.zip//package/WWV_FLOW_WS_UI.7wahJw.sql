create package wwv_flow_ws_ui
as

procedure show_tabs (
    p_app_id  in number,
    p_session in number);



end wwv_flow_ws_ui;
/

