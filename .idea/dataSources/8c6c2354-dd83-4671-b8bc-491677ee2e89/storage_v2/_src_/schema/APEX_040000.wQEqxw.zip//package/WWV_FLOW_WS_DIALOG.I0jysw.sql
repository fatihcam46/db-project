create package wwv_flow_ws_dialog
As

procedure websheet_properties (
    p_worksheet_id   in number,
    p_base_report_id in number,
    p_app_user       in varchar2,
	p_mode           in varchar2 default 'REPORT'
    );

procedure add_column (
    p_worksheet_id   in number,
	p_mode           in varchar2 default 'REPORT'
    );

procedure column_properties (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
    p_column_name         in varchar2 default null,
    p_mode                in varchar2 default 'REPORT');

procedure list_of_values_text (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
    p_lov_id              in number default null,
    p_mode                in varchar2 default 'REPORT');

procedure list_of_values (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
    p_lov_id              in number default null,
    p_mode                in varchar2 default 'REPORT');

procedure remove_columns (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
	p_mode                in varchar2 default 'REPORT'
	);

procedure set_column_value (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure replace_value (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure fill (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure delete_rows (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure geocode (
    p_worksheet_id     in number,
    p_base_report_id   in number,
    p_app_user         in varchar2,
	p_mode             in varchar2 default 'REPORT');

procedure copy (
    p_worksheet_id in number,
	p_mode         in varchar2 default 'REPORT'
    );

procedure export (
    p_worksheet_id in number,
	p_mode         in varchar2 default 'REPORT'
    );

procedure delete_websheet (
    p_worksheet_id     in number,
    p_base_report_id   in number,
    p_app_user         in varchar2,
	p_mode             in varchar2 default 'REPORT');

procedure column_groups (
    p_worksheet_id     in number,
    p_base_report_id   in number,
    p_app_user         in varchar2,
    p_group_id         in number default null,
    p_mode             in varchar2 default 'REPORT');

procedure reset_geocode (
    p_worksheet_id   in number,
    p_websheet_id    in number,
    p_base_report_id in number,
    p_app_user       in varchar2,
	p_mode           in varchar2 default 'REPORT');

procedure column_expression  (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT'
    );

procedure add_attachment (
    p_worksheet_id  in number,
	p_mode          in varchar2 default 'REPORT'
    );

procedure add_notes (
    p_worksheet_id  in number default null,
	p_mode          in varchar2 default 'REPORT',
	p_note_id       in number default null
    );

procedure add_links (
    p_worksheet_id  in number,
	p_mode          in varchar2 default 'REPORT',
	p_link_id       in number default null
    );

procedure add_tags (
    p_worksheet_id  in number,
    p_row_id        in number,
	p_mode          in varchar2 default 'REPORT'
    );

procedure move_columns (
    p_worksheet_id     in number,
	p_mode             in varchar2 default 'REPORT'
    );

procedure add_column_validation (
    p_worksheet_id    in number,
    p_app_user        in varchar2,
    p_base_report_id  in number,
    p_validation_id   in number         default null,
    p_column_name     in varchar2       default null,
	p_mode            in varchar2       default 'REPORT'
    );

end  wwv_flow_ws_dialog;
/

