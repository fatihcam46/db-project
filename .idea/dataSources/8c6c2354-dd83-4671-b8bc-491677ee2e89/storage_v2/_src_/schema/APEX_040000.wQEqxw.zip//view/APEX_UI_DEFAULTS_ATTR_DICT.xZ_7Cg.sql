create view APEX_UI_DEFAULTS_ATTR_DICT as
select
    w.short_name workspace,
    --
    syn.syn_name column_name,
    case when c.column_name != syn.syn_name
         then c.column_name
         end synonym_of,
    c.label,
    c.help_text,
    c.format_mask,
    c.default_value,
    c.form_format_mask,
    c.form_display_width,
    c.form_display_height,
    c.form_data_type,
    c.report_format_mask,
    c.report_col_alignment,
    c.created_by,
    c.created_on,
    c.last_updated_by,
    c.last_updated_on
from wwv_flow_hnt_column_dict c,
     wwv_flow_hnt_col_dict_syn syn,
     wwv_flow_company_schemas s,
     wwv_flow_companies w,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      c.security_group_id = w.PROVISIONING_COMPANY_ID and
      c.column_id = syn.column_id and
      syn.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      d.sgid != 0 and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_UI_DEFAULTS_ATTR_DICT is 'The Attribute Dictionary is specific to a workspace.  It is part of User Interface Defaults and can be used in report and form creation.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.COLUMN_NAME is 'Name of column or synonym.  Used to match against columns when UI Defaults are used by create wizards.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.SYNONYM_OF is 'If a synonym, the name of the base column that it is a synonym of.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.LABEL is 'Used for item label and report column heading.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.HELP_TEXT is 'Used for help text for items and interactive report columns.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.FORMAT_MASK is 'Used as the format mask for items and report columns.  Can be overwritten by report for form specific format masks.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.DEFAULT_VALUE is 'Used as the default value for items.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.FORM_FORMAT_MASK is 'If provided, used as the format mask for items, overriding any value for the general format mask.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.FORM_DISPLAY_WIDTH is 'Used as the width of any items using this Attribute Definition.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.FORM_DISPLAY_HEIGHT is 'Used as the height of any items using this Attribute Definition (only used by item types such as textares and shuttles).'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.FORM_DATA_TYPE is 'Used as the data type for items (specifies whether this item contains VARCHAR or NUMBER data which results in an automatic validation).'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.REPORT_FORMAT_MASK is 'If provided, used as the format mask for report columns, overriding any value for the general format mask.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.REPORT_COL_ALIGNMENT is 'Used as the alignment for report column data (e.g. number are usually right justified).'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.CREATED_BY is 'User that created this column.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.CREATED_ON is 'Date this column was created.'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_UI_DEFAULTS_ATTR_DICT.LAST_UPDATED_ON is 'Date of last update'
/

