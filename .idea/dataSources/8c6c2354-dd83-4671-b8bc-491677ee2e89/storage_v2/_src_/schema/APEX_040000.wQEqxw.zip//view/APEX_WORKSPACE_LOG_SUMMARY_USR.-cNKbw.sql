create view APEX_WORKSPACE_LOG_SUMMARY_USR as
select
           w.short_name                           workspace,
           nvl(l.userid,'PUBLIC')                 apex_user,
           count(distinct l.flow_id)              applications,
           count(*)                               page_views,
           count(distinct l.flow_id||'.'||l.step_id) distinct_pages,
           sum(l.elap)                            total_elapsed_time,
           avg(l.elap)                            average_elapsed_time,
           min(l.elap)                            minimum_elapsed_time,
           max(l.elap)                            maximum_elapsed_time,
           sum(l.num_rows)                        total_rows_queried,
           count(distinct l.ip_address)           distinct_ip_addresses,
           count(distinct l.USER_AGENT)           distinct_agents,
           count(distinct l.session_id)           distinct_apex_sessions,
           sum(decode(l.sqlerrm,null,0,1))        page_views_with_errors,
           sum(decode(l.page_mode,'D',1,'C',1,0)) dynamic_page_views,
           sum(decode(l.page_mode,'R',1,0))       cached_page_views,
           min(l.time_stamp)                      first_view,
           max(l.time_stamp)                      last_view,
           max(l.time_stamp)-min(l.time_stamp)    period_in_days,
           --
           sum(decode(greatest(s.the_date - (1/1440),l.time_stamp),l.time_stamp,1,0) )  last_1_minute,
           sum(decode(greatest(s.the_date - (5/1440),l.time_stamp),l.time_stamp,1,0) )  last_5_minutes,
           sum(decode(greatest(s.the_date - (10/1440),l.time_stamp),l.time_stamp,1,0) ) last_10_minutes,
           sum(decode(greatest(s.the_date - (15/1440),l.time_stamp),l.time_stamp,1,0) ) last_15_minutes,
           sum(decode(greatest(s.the_date - (30/1440),l.time_stamp),l.time_stamp,1,0) ) last_30_minutes,
           sum(decode(greatest(s.the_date - (1/24),l.time_stamp),l.time_stamp,1,0) )    last_1_hour,
           sum(decode(greatest(s.the_date - (2/24),l.time_stamp),l.time_stamp,1,0) )    last_2_hours,
           sum(decode(greatest(s.the_date - (6/24),l.time_stamp),l.time_stamp,1,0) )    last_6_hours,
           sum(decode(greatest(s.the_date - (2/24),l.time_stamp),l.time_stamp,1,0) )    last_12_hours,
           sum(decode(greatest(s.the_date - 1,l.time_stamp),l.time_stamp,1,0)      )    last_24_hours,
           sum(decode(greatest(s.the_date - 2,l.time_stamp),l.time_stamp,1,0)      )    last_48_hours,
           sum(decode(greatest(s.the_date - 7,l.time_stamp),l.time_stamp,1,0)      )    last_7_days,
           sum(decode(greatest(s.the_date - 14,l.time_stamp),l.time_stamp,1,0)     )    last_14_days,
           --
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'01',1,0),0))  today_HH01,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'02',1,0),0))  today_HH02,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'03',1,0),0))  today_HH03,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'04',1,0),0))  today_HH04,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'05',1,0),0))  today_HH05,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'06',1,0),0))  today_HH06,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'07',1,0),0))  today_HH07,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'08',1,0),0))  today_HH08,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'09',1,0),0))  today_HH09,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'10',1,0),0))  today_HH10,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'11',1,0),0))  today_HH11,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'12',1,0),0))  today_HH12,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'13',1,0),0))  today_HH13,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'14',1,0),0))  today_HH14,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'15',1,0),0))  today_HH15,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'16',1,0),0))  today_HH16,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'17',1,0),0))  today_HH17,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'18',1,0),0))  today_HH18,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'19',1,0),0))  today_HH19,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'20',1,0),0))  today_HH20,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'21',1,0),0))  today_HH21,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'22',1,0),0))  today_HH22,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'23',1,0),0))  today_HH23,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,decode(to_char(l.time_stamp,'HH24'),'24',1,0),0))  today_HH24,
           sum(decode(greatest(trunc(s.the_date),l.time_stamp),l.time_stamp,1,0))                                              today
from wwv_flow_activity_log l,
     wwv_flows f,
     wwv_flow_companies w,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d,
     (select sysdate the_date from dual) s
where (l.security_group_id in (select security_group_id from  wwv_flow_company_schemas where schema = user) or
       user in ('SYS','SYSTEM', 'APEX_040000')  or
       d.sgid = l.security_group_id) and
       --
       l.security_group_id = w.PROVISIONING_COMPANY_ID and
       l.flow_id = f.id(+) and
       l.time_stamp > sysdate - 14 and
      w.PROVISIONING_COMPANY_ID != 0
group by w.short_name, nvl(l.userid,'PUBLIC')
/

comment on table APEX_WORKSPACE_LOG_SUMMARY_USR is 'Page view activity log summarized by user for the last two weeks'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.WORKSPACE is 'Name of Workspace that generated the page view log entry'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.APEX_USER is 'Name of the APEX User name associated with the page view log entry'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.APPLICATIONS is 'Number of applications contained in the aggregation by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.PAGE_VIEWS is 'Page views aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.DISTINCT_PAGES is 'Distinct page views aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TOTAL_ELAPSED_TIME is 'Total elapsed time logged aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.AVERAGE_ELAPSED_TIME is 'Average elapsed time logged aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.MINIMUM_ELAPSED_TIME is 'Minimum elapsed time logged aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.MAXIMUM_ELAPSED_TIME is 'Maximum elapsed time aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TOTAL_ROWS_QUERIED is 'Total rows queried by the APEX reporting engine aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.DISTINCT_IP_ADDRESSES is 'Distinct IP addresses aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.DISTINCT_AGENTS is 'Distinct User Agents aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.DISTINCT_APEX_SESSIONS is 'Distinct APEX Sessions aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.PAGE_VIEWS_WITH_ERRORS is 'Count of page views with recorded errors aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.DYNAMIC_PAGE_VIEWS is 'Count of dynamic page views aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.CACHED_PAGE_VIEWS is 'Count of cached page views aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.FIRST_VIEW is 'Date of first page view by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_VIEW is 'Date of most recent page view by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.PERIOD_IN_DAYS is 'Period in days between the first recorded page view an the most recent page view'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_1_MINUTE is 'Page views recorded in the last 1 minute aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_5_MINUTES is 'Page views recorded in the last 5 minutes aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_10_MINUTES is 'Page views recorded in the last 10 minutes aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_15_MINUTES is 'Page views recorded in the last 15 minutes aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_30_MINUTES is 'Page views recorded in the last 30 minutes aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_1_HOUR is 'Page views recorded in the last 1 hour aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_2_HOURS is 'Page views recorded in the last 2 hours aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_6_HOURS is 'Page views recorded in the last 6 hours aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_12_HOURS is 'Page views recorded in the last 12 hours aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_24_HOURS is 'Page views recorded in the last 24 hours aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_48_HOURS is 'Page views recorded in the last 48 hours aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_7_DAYS is 'Page views recorded in the last 7 days aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.LAST_14_DAYS is 'Page views recorded in the last 14 days aggregated by APEX User Name and Workspace'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH01 is 'Page views recorded today for the hour 00-01'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH02 is 'Page views recorded today for the hour 01-02'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH03 is 'Page views recorded today for the hour 02-03'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH04 is 'Page views recorded today for the hour 03-04'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH05 is 'Page views recorded today for the hour 04-05'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH06 is 'Page views recorded today for the hour 05-06'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH07 is 'Page views recorded today for the hour 06-07'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH08 is 'Page views recorded today for the hour 07-08'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH09 is 'Page views recorded today for the hour 08-09'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH10 is 'Page views recorded today for the hour 09-10'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH11 is 'Page views recorded today for the hour 10-11'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH12 is 'Page views recorded today for the hour 11-12'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH13 is 'Page views recorded today for the hour 12-13'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH14 is 'Page views recorded today for the hour 13-14'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH15 is 'Page views recorded today for the hour 14-15'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH16 is 'Page views recorded today for the hour 15-16'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH17 is 'Page views recorded today for the hour 16-17'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH18 is 'Page views recorded today for the hour 17-18'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH19 is 'Page views recorded today for the hour 18-19'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH20 is 'Page views recorded today for the hour 19-20'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH21 is 'Page views recorded today for the hour 20-21'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH22 is 'Page views recorded today for the hour 21-22'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH23 is 'Page views recorded today for the hour 22-23'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY_HH24 is 'Page views recorded today for the hour 23-24'
/

comment on column APEX_WORKSPACE_LOG_SUMMARY_USR.TODAY is 'Todays date on the server to provide greater context for people in different timezones'
/

