create trigger WWV_PURGE_WORKSPACE_RESP_TRG1
    before insert
    on WWV_PURGE_WORKSPACE_RESPONSES
    for each row
begin
    if :new.id is null then
        :new.id := to_number(sys_guid(),'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
    end if;
    :new.created_ts := systimestamp;
end;
/

