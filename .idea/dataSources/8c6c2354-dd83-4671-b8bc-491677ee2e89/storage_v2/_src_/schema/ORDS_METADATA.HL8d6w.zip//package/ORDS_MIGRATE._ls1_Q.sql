create PACKAGE ORDS_MIGRATE AUTHID DEFINER AS
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2014. All Rights Reserved.
--
--    NAME
--      ords_migrate.pls
--
--    DESCRIPTION
--      This package migrates APEX 4.2.x and later for RESTful Services definitions to ORDS.
--
--
--    MODIFIED   (MM/DD/YYYY)
--    epaglina    07/07/2014 - Created.
--    epaglina    12/07/2017 - Add procedure to migrate REST definitions from a specific Application Express workspace .
--
--------------------------------------------------------------------------------

  /**
   * Migrate all Application Express RESTful Services definitions (version 4.2.x or later)
   * to Oracle REST Data Services tables.
   * 
   * If an existing APEX REST module, roles, privileges, etc. 
   * has been previously migrated, it will be replaced.
   */
  PROCEDURE migrate_apex_restful_services;

  /**
   * Migrate Application Express RESTful Services definitions (version 4.2.x or later)
   * for a specific workspace to Oracle REST Data Services tables.
   * 
   * If an existing APEX REST module, roles, privileges, etc. 
   * has been previously migrated, it will be replaced.
   * 
   * @param p_workspace_name         The Application Express workspace name.
   */
  PROCEDURE migrate_apex_workspace_rest(p_workspace_name IN VARCHAR2);

END;
/

