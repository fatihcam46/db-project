create TYPE BODY t_ords_module_privilege  IS
  CONSTRUCTOR FUNCTION t_ords_module_privilege (
      privilege_name       IN VARCHAR2,
      module_name          IN VARCHAR2,
      created_on           IN DATE,
      created_by           IN VARCHAR2,
      updated_on           IN DATE,
      updated_by           IN VARCHAR2
    ) RETURN SELF AS RESULT
  AS
  BEGIN
    SELF.module_name        := module_name;
    SELF.privilege_name     := privilege_name;
    SELF.comments           := NULL;
    SELF.created_on         := created_on;
    SELF.created_by         := created_by;
    SELF.updated_on         := updated_on;
    SELF.updated_by         := updated_by;
    RETURN;
  END;
END;
/

