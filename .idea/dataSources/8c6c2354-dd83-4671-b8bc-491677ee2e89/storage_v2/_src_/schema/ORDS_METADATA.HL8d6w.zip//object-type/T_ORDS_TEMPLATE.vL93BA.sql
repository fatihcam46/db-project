create TYPE  t_ords_template UNDER t_ords_metadata_type
   ("PATTERN"      VARCHAR2(600 BYTE), 
    "PRIORITY"     NUMBER, 
    "ETAG_TYPE"    VARCHAR2(30 BYTE), 
    "ETAG_QUERY"   VARCHAR2(4000 BYTE), 
    "HANDLER_LIST" t_ords_handler_list, 
    CONSTRUCTOR FUNCTION t_ords_template (
      pattern            IN VARCHAR2,
      priority           IN NUMBER   DEFAULT 0,
      etag_type          IN VARCHAR2 DEFAULT 'HASH',
      etag_query         IN VARCHAR2 DEFAULT NULL,
      comments           IN VARCHAR2 DEFAULT NULL,
      handler_list       IN t_ords_handler_list,
      created_on         IN DATE     DEFAULT NULL,
      created_by         IN VARCHAR2 DEFAULT NULL,
      updated_on         IN DATE     DEFAULT NULL,
      updated_by         IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT,
    CONSTRUCTOR FUNCTION t_ords_template (
      pattern            IN VARCHAR2,
      priority           IN NUMBER DEFAULT 0,
      etag_type          IN VARCHAR2 DEFAULT 'HASH',
      etag_query         IN VARCHAR2 DEFAULT NULL,
      comments           IN VARCHAR2 DEFAULT NULL,
      handler            IN t_ords_handler DEFAULT NULL,
      created_on         IN DATE     DEFAULT NULL,
      created_by         IN VARCHAR2 DEFAULT NULL,
      updated_on         IN DATE     DEFAULT NULL,
      updated_by         IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT
   );
/

