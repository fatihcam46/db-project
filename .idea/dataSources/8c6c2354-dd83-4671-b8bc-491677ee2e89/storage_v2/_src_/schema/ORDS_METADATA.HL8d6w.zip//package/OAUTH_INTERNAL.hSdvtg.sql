create PACKAGE OAUTH_INTERNAL AUTHID definer
AS
  not_authorized EXCEPTION;
  PRAGMA EXCEPTION_INIT(not_authorized, -01031);

  logo_size_code            CONSTANT NUMBER        := -20031;
  invalid_logo_type_code    CONSTANT NUMBER        := -20032;
  invalid_email_code        CONSTANT NUMBER        := -20033;

  c_logo_max_size_bytes     CONSTANT NUMBER        := 100*1024; -- 100 KB



  /**
  * Internal, security checks are done by the caller
  *
  * @param p_status If 'APPROVED' OAUTH APPROVAL is enabled, if 'DENIED' it is disabled.
  * @param p_updated_by The user you want to update as.
  * @param p_approval_user The name of the oauth user owning the approval.
  * @param p_approval_id The id of the approval to modify
  */
  PROCEDURE modify_approval_status(
      p_status      VARCHAR2,
      p_updated_by  VARCHAR2,

      p_approval_user VARCHAR2,
      p_approval_id NUMBER );

  /**
  * Internal, security checks are done by the caller
  *
  * Updates the client information
  *
  * @param p_id The ID of the client to be modified
  * @param p_editing_user The user you want to update as.

  * @param p_name The name of the client
  * @param p_description The description of the client
  * @param p_origins_allowed allowed origins
  * @param p_redirect_uri Redirect URI
  * @param p_support_email Support e-mail for client users
  * @param p_support_uri Support URI for client users
  */
  PROCEDURE update_client(
      p_id   NUMBER,
      p_editing_user VARCHAR2,

      p_name         VARCHAR2,
      p_description  VARCHAR2,
      p_origins_allowed VARCHAR2,
      p_redirect_uri VARCHAR2,
      p_support_email VARCHAR2,
      p_support_uri   VARCHAR2);

  /**
  * Internal use, security checks must be done by the caller
  *
  * Updates the client logo file
  *
  * @param p_id The ID of the client owner of the logo
  * @param p_editing_user The user you want to update as.

  * @param p_content_type The content type of the logo
  * @param p_logo de logo binary
  */
  PROCEDURE update_client_logo(
      p_id   NUMBER,
      p_editing_user VARCHAR2,

      p_content_type VARCHAR2,
      p_logo  BLOB);

  /**
  * Removes a client and all of the related privileges
  *
  * @param p_client_id The ID of the client to be removed
  * @param p_editing_user The user you want to remove as.
  */
  PROCEDURE delete_client(
      p_client_id   NUMBER,
      p_schema VARCHAR2);

  /**
  * Creates a new client
  *
  * @param p_editing_user The user you want to create as.
  * @param p_schema The schema related to the client.
  * @param p_name The name of the client
  * @param p_description The description of the client
  * @param p_response_type The response type 'TOKEN' or 'CODE'
  * @param p_origins_allowed allowed origins
  * @param p_redirect_uri Redirect URI
  * @param p_support_email Support e-mail for client users
  * @param p_support_uri Support URI for client users
  * @param p_auth_flow The auth flow, typically 'AUTH_CODE'
  * @param p_priv_names Comma separated privilege names
  *
  * RETURNING the ID of the client created
  */
  FUNCTION create_client(
      p_editing_user VARCHAR2,
      p_schema       VARCHAR2,

      p_name         VARCHAR2,
      p_description  VARCHAR2,
      p_response_type VARCHAR2,
      p_origins_allowed VARCHAR2,
      p_redirect_uri VARCHAR2,
      p_support_email VARCHAR2,
      p_support_uri   VARCHAR2,
      p_auth_flow     VARCHAR2) RETURN NUMBER;

  /**
  * Synchs client privileges with a comma separated list of
  * comma separated values representing the ids
  */
  PROCEDURE update_client_privileges(
      p_client_id   NUMBER,
      p_editing_user VARCHAR2,
      p_priv_names   t_ords_vchar_tab);

  FUNCTION create_pending_approval(
    p_editing_user VARCHAR2,

    p_state         VARCHAR2,
    p_approval_id  NUMBER,
    p_schema VARCHAR2
    ) RETURN NUMBER;

  FUNCTION create_approval(
    p_editing_user VARCHAR2,
    p_schema VARCHAR2,

    p_status       VARCHAR2,
    p_client_id    NUMBER

    ) RETURN NUMBER;

  FUNCTION create_approval_privilege(
    p_editing_user VARCHAR2,
    p_schema VARCHAR2,

    p_approval_id    NUMBER,
    p_privilege_id NUMBER

    ) RETURN NUMBER;

  FUNCTION create_session(
    p_editing_user VARCHAR2,

    p_state         CLOB,
    p_approval_id  NUMBER,

    p_bearer_token VARCHAR2,
    p_refresh_token VARCHAR2,
    p_token_duration  NUMBER,
    p_refresh_duration NUMBER,

    p_first_party_token VARCHAR2,
    p_first_party_duration NUMBER,
    p_auth_code_token VARCHAR2,
    p_auth_code_duration NUMBER,
    p_schema VARCHAR2)
  RETURN NUMBER;



  PROCEDURE delete_session(
    p_session_id VARCHAR2,
    p_schema     VARCHAR2);


  FUNCTION approval_by_token(
    p_token VARCHAR2,
    p_token_type    VARCHAR2,
    p_schema        VARCHAR2
  ) RETURN NUMBER;


  FUNCTION session_by_token(
    p_token VARCHAR2,
    p_token_type    VARCHAR2,
    p_schema        VARCHAR2
  ) RETURN NUMBER;

  FUNCTION update_approval(
    p_editing_user VARCHAR2,

    p_pending_id  NUMBER,
    p_status  VARCHAR2,
    p_schema  VARCHAR2
  ) RETURN NUMBER;

  FUNCTION verify_client(
    p_client_identifier  VARCHAR2,
    p_client_secret  VARCHAR2,
    p_schema VARCHAR2
  ) RETURN sys_refcursor;

  FUNCTION state_from_bearer(p_bearer_token VARCHAR2, p_schema VARCHAR2) RETURN CLOB;

  FUNCTION session_state(p_session_id NUMBER, p_schema VARCHAR2) RETURN CLOB;

  PROCEDURE create_approval_privilege(p_editing_user VARCHAR2, p_approval_id NUMBER, p_privilege_id NUMBER, p_schema VARCHAR2);

  FUNCTION approval_privs_valid(p_approval_id NUMBER, p_schema VARCHAR2) RETURN VARCHAR2;

  FUNCTION pending_approval_privs_valid(p_papproval_id NUMBER, p_schema VARCHAR2) RETURN VARCHAR2;

  FUNCTION bearer_approval_valid(p_bearer VARCHAR2, p_schema VARCHAR2) RETURN VARCHAR2;

  function grant_client_role(
    p_schema_id number,
    p_client_id number,
    p_role_id number) return number;

  procedure revoke_client_role(
    p_schema_id number,
    p_client_id number,
    p_role_id number);

  FUNCTION revoke_token(
      p_current_user VARCHAR2,
      p_client_id         VARCHAR2,
      p_client_secret  VARCHAR2,
      p_token VARCHAR2,
      p_token_hint VARCHAR2,
      p_revoke_policy VARCHAR2) RETURN VARCHAR2;


  procedure rename_client(
    p_client_db_id number,
    p_new_name varchar2,
    p_editing_user varchar2);

END OAUTH_INTERNAL;
/

