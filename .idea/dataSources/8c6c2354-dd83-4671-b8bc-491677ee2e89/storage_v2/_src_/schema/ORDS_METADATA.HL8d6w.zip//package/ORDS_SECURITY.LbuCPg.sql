create package               ORDS_SECURITY AUTHID current_user as 

  /**
   * Determines the identity of the current session user IFF called directly
   * from an anonymous block or another package/procedure/function defined with AUTHID current_user
   */
  function current_user return varchar2;

  /**
   * Determine if the current user is allowed to operate on the specified schema
   * @param p_schema indicates the schema that is attempting to be accessed
   * @return if p_schema is null returns the schema of the current user. If p_schema is not null checks that the current user is authorized to manipulate the named schema.
   */
  function check_schema(p_schema varchar2,       
                        p_as_rest_schema BOOLEAN DEFAULT TRUE,
                        p_as_opu         BOOLEAN DEFAULT FALSE) return varchar2;

  /**
   * Determine the schema id associated with the specified schema
   * @param p_schema indicates the schema to determine a schema_id for. If p_schema is null then the current schema is used. The current user is checked to ensure they have access to the schema
   * @return schema_id of the current schema or the schema specified by p_schema
   */
  function schema_id(p_schema varchar2) return number;

  /**
   * Determine if the current user is allowed to administer the specified schema
   * @param p_schema indicates the schema that is attempting to be accessed
   * @return if p_schema is null returns the schema of the current user. If p_schema is not null checks that the current user is authorized to manipulate the named schema.
   */
  function check_schema_admin(p_schema varchar2,       
                              p_as_rest_schema BOOLEAN DEFAULT TRUE,
                              p_as_opu         BOOLEAN DEFAULT FALSE) return varchar2;

  /**
   * Determine the schema id associated with the specified schema
   * @param p_schema indicates the schema to determine a schema_id for. If p_schema is null then the current schema is used. The current user is checked to ensure they have admini access to the schema
   * @return schema_id of the current schema or the schema specified by p_schema
   */
  function schema_id_admin(p_schema varchar2) return number;

end ords_security;
/

