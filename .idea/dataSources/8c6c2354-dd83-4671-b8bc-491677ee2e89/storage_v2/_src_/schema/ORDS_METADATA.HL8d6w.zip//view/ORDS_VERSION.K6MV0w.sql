create view ORDS_VERSION as
SELECT ords_schema_version.version
FROM ords_schema_version
WHERE ords_schema_version.created_on =
  (SELECT MAX(ords_schema_version.created_on) FROM ords_schema_version
  )
AND ROWNUM = 1
/

