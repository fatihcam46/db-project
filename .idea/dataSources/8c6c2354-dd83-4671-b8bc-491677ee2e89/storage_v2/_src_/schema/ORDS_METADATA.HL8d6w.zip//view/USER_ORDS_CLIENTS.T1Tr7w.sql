create view USER_ORDS_CLIENTS as
SELECT c.id,
  c.name,
  c.description,
  c.auth_flow,
  c.apex_application_id,
  c.response_type,
  c.client_id,
  c.client_secret,
  c.redirect_uri,
  c.support_email,
  c.support_uri,
  c.allowed_origins,
  c.about_url,
  c.logo_content_type,
  c.logo_image,
  c.schema_id,
  c.created_by,
  c.created_on,
  c.updated_by,
  c.updated_on
FROM oauth_clients c,
  ords_schemas s
WHERE c.schema_id    = s.id
AND nlssort(s.parsing_schema,'NLS_SORT=BINARY') = nlssort(sys_context('USERENV', 'CURRENT_USER'),'NLS_SORT=BINARY')
/

