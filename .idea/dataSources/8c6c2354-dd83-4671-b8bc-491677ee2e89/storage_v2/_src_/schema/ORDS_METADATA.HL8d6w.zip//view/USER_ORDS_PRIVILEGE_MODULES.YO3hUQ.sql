create view USER_ORDS_PRIVILEGE_MODULES as
SELECT sec_privilege_modules.module_id,
  USER_ORDS_MODULES.name AS module_name,
  sec_privilege_modules.privilege_id,
  USER_ORDS_PRIVILEGES.name AS privilege_name
FROM USER_ORDS_PRIVILEGES,
  USER_ORDS_MODULES,
  sec_privilege_modules
WHERE sec_privilege_modules.module_id  = USER_ORDS_MODULES.id
AND sec_privilege_modules.privilege_id = USER_ORDS_PRIVILEGES.id
/

