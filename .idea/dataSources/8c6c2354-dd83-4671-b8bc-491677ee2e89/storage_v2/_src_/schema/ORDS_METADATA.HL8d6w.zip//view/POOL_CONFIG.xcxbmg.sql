create view POOL_CONFIG as
SELECT NULL                    AS pool_name,
  ords_schemas.parsing_schema  AS workspace_identifier,
  ords_url_mappings.type       AS type,
  ords_url_mappings.pattern    AS uri,
  ords_url_mappings.updated_on AS updated,
  sec_keys.enc_key             AS enc_key,
  sec_keys.mac_key             AS mac_key
FROM ords_schemas,
  ords_url_mappings,
  sec_keys
WHERE ords_url_mappings.id  = ords_schemas.url_mapping_id
AND ords_schemas.id         = sec_keys.schema_id
AND ords_url_mappings.type <> 'NONE'
AND ords_schemas.status     = 'ENABLED'
ORDER BY updated DESC
/

