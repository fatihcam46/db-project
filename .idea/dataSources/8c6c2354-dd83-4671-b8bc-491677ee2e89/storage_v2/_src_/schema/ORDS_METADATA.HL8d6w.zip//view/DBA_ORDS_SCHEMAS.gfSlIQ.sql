create view DBA_ORDS_SCHEMAS as
SELECT
    ords_schemas.id,
    ords_schemas.url_mapping_id,
    ords_schemas.parsing_schema,
    ords_schemas.status,
    ords_schemas.auto_rest_auth,
    ords_schemas.ops_allowed,
    ords_schemas.pre_hook,
    ords_schemas.updated_on,
    ords_schemas.updated_by,
    ords_schemas.created_on,
    ords_schemas.created_by
FROM
    ords_schemas
WHERE
    ords_schemas.id <> 10
/

