create PACKAGE               ORDS_UTIL AUTHID definer
AS
/**  Copyright (c) Oracle Corporation 2014. All Rights Reserved.
 * 
 *     NAME
 *       ords_util.pls
 * 
 *     DESCRIPTION
 *       This package declares immutable utility methods
 * 
 *     MODIFIED    (MM/DD/YYYY)
 *      dwhittin    06/10/2020 - created.
 */  
END ORDS_UTIL;
/

