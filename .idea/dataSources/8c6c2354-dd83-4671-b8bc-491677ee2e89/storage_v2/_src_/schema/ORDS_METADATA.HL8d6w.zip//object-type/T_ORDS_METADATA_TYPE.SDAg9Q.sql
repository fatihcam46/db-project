create TYPE  t_ords_metadata_type AUTHID DEFINER AS OBJECT
   ("COMMENTS"           VARCHAR2(4000 BYTE), 
    "CREATED_BY"         VARCHAR2(255 BYTE), 
    "CREATED_ON"         DATE, 
    "UPDATED_BY"         VARCHAR2(255 BYTE), 
    "UPDATED_ON"         DATE
   ) NOT FINAL NOT INSTANTIABLE;
/

