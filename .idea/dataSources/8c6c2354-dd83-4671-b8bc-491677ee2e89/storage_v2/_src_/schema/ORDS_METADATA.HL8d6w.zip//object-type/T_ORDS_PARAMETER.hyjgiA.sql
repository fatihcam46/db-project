create TYPE  t_ords_parameter UNDER t_ords_metadata_type
   ("NAME"               VARCHAR2(100 BYTE), 
    "BIND_VARIABLE_NAME" VARCHAR2(30 BYTE), 
    "SOURCE_TYPE"        VARCHAR2(20 BYTE), 
    "ACCESS_METHOD"      VARCHAR2(10 BYTE), 
    "PARAM_TYPE"         VARCHAR2(30 BYTE), 
    CONSTRUCTOR FUNCTION t_ords_parameter (
      name                 IN VARCHAR2,
      bind_variable_name   IN VARCHAR2 DEFAULT NULL,
      source_type          IN VARCHAR2 DEFAULT 'HEADER',
      param_type           IN VARCHAR2 DEFAULT 'STRING',
      access_method        IN VARCHAR2 DEFAULT 'IN',
      comments             IN VARCHAR2 DEFAULT NULL,
      created_on           IN DATE     DEFAULT NULL,
      created_by           IN VARCHAR2 DEFAULT NULL,
      updated_on           IN DATE     DEFAULT NULL,
      updated_by           IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT
   );
/

