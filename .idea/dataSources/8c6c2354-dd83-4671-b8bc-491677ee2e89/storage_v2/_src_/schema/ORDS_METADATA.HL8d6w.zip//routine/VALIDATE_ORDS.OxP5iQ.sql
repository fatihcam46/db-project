create procedure validate_ords authid definer
as
    type name_array      is varray(100) of varchar2(255);
    type counter_array   is table of pls_integer index by varchar2(255);

    c_granted_role   constant all_objects.object_type%type := 'GRANTED ROLE';
    c_pkg_type       constant all_objects.object_type%type := 'PACKAGE';
    c_pkg_body_type  constant all_objects.object_type%type := 'PACKAGE BODY';
    c_proc_type      constant all_objects.object_type%type := 'PROCEDURE';
    c_role_type      constant all_objects.object_type%type := 'ROLE';
    c_seq_type       constant all_objects.object_type%type := 'SEQUENCE';
    c_syn_type       constant all_objects.object_type%type := 'SYNONYM';      
    c_table_type     constant all_objects.object_type%type := 'TABLE';
    c_view_type      constant all_objects.object_type%type := 'VIEW';

    tbl_names            constant name_array := name_array               
                           ('CFG_PLSQL_GATEWAYS','OAUTH_APPROVAL_PRIVS','OAUTH_APPROVALS','OAUTH_CLIENT_PRIVILEGES',
                            'OAUTH_CLIENT_ROLES','OAUTH_CLIENTS','OAUTH_PENDING_APPROVALS',
                            'OAUTH_SESSIONS','ORDS_HANDLERS','ORDS_MODULES','ORDS_OBJECTS',
                            'ORDS_PARAMETERS','ORDS_SCHEMA_VERSION','ORDS_SCHEMAS',
                            'ORDS_TEMPLATES','ORDS_URL_MAPPINGS','ORDS_WORKSPACE_SCHEMAS',
                            'SEC_AUTHENTICATORS','SEC_KEYS','SEC_ORIGINS_ALLOWED_MODULES',
                            'SEC_PRIVILEGE_AUTHS','SEC_PRIVILEGE_MAPPINGS','SEC_PRIVILEGE_MODULES',
                            'SEC_PRIVILEGE_ROLES','SEC_PRIVILEGES','SEC_ROLE_MAPPINGS','SEC_ROLES','SEC_SESSIONS'
                           );

    pkg_names            constant name_array := name_array
                           ('OAUTH','OAUTH_INTERNAL','ORDS',
                            'ORDS_ADMIN','ORDS_CONSTANTS','ORDS_EXPORT','ORDS_INTERNAL','ORDS_MIGRATE',
                            'ORDS_OPER','ORDS_SECURITY','ORDS_SERVICES','ORDS_SERVICES_INTERNAL','ORDS_UTIL',
                            'OSDDM_DBMS_MD_DDL'
                           );

    proc_names           constant name_array := name_array
                           ('VALIDATE_ORDS');

    pubsyn_names         constant name_array := name_array
                           ('DBA_ORDS_SCHEMAS','DBA_ORDS_URL_MAPPINGS',
                            'OAUTH','ORDS','ORDS_ADMIN','ORDS_CONSTANTS','ORDS_EXPORT','ORDS_MIGRATE',
                            'ORDS_OPER','ORDS_SERVICES','ORDS_UTIL','OSDDM_DBMS_MD_DDL',
                            'T_ORDS_ATTR_SUPPORT_OBJ','T_ORDS_ATTR_SUPPORT_TAB','T_ORDS_HANDLER',
                            'T_ORDS_HANDLER_LIST','T_ORDS_METADATA_TYPE','T_ORDS_METADATA_TYPE_LIST',
                            'T_ORDS_MODULE','T_ORDS_MODULE_LIST','T_ORDS_MODULE_ORIGINS_ALLOWED',
                            'T_ORDS_MODULE_PRIVILEGE','T_ORDS_NUM_TAB','T_ORDS_PARAMETER',
                            'T_ORDS_PARAMETER_LIST','T_ORDS_TEMPLATE','T_ORDS_TEMPLATE_LIST','T_ORDS_VCHAR_TAB',
                            'USER_ORDS_APPROVALS','USER_ORDS_CLIENTS','USER_ORDS_CLIENT_PRIVILEGES',
                            'USER_ORDS_CLIENT_ROLES','USER_ORDS_ENABLED_OBJECTS','USER_ORDS_HANDLERS',
                            'USER_ORDS_MODULES','USER_ORDS_OBJECTS','USER_ORDS_OBJ_MEMBERS',
                            'USER_ORDS_PARAMETERS','USER_ORDS_PENDING_APPROVALS','USER_ORDS_PRIVILEGES',
                            'USER_ORDS_PRIVILEGE_MAPPINGS','USER_ORDS_PRIVILEGE_MODULES','USER_ORDS_PRIVILEGE_ROLES',
                            'USER_ORDS_REPOVERSIONS','USER_ORDS_ROLES','USER_ORDS_SCHEMAS',
                            'USER_ORDS_SERVICES','USER_ORDS_TEMPLATES'
                           );

    role_names            constant name_array := name_array
                           ('ORDS_ADMINISTRATOR_ROLE', 'ORDS_RUNTIME_ROLE');

    seq_names            constant name_array := name_array
                           ('ORDS_ID_SEQ');

    view_names           constant name_array := name_array
                           ('APEX_WWV_FLOW_POOL_CONFIG','DBA_ORDS_SCHEMAS','DBA_ORDS_URL_MAPPINGS',
                            'ORDS_CLIENT_ROLES','ORDS_MODULE_SERVICES',
                            'ORDS_PRIVILEGE_MAPPINGS','ORDS_REPVERSION','ORDS_VERSION',
                            'PLSQL_GATEWAY_CONFIG','POOL_CONFIG','UNIFIED_POOL_CONFIG',
                            'USER_ORDS_APPROVALS','USER_ORDS_CLIENTS','USER_ORDS_CLIENT_PRIVILEGES',
                            'USER_ORDS_CLIENT_ROLES','USER_ORDS_ENABLED_OBJECTS','USER_ORDS_HANDLERS',
                            'USER_ORDS_MODULES','USER_ORDS_OBJECTS','USER_ORDS_OBJ_MEMBERS',
                            'USER_ORDS_PARAMETERS','USER_ORDS_PENDING_APPROVALS','USER_ORDS_PRIVILEGES',
                            'USER_ORDS_PRIVILEGE_MAPPINGS','USER_ORDS_PRIVILEGE_MODULES','USER_ORDS_PRIVILEGE_ROLES',
                            'USER_ORDS_ROLES','USER_ORDS_SCHEMAS','USER_ORDS_SERVICES','USER_ORDS_TEMPLATES'
                           );

    apex_view_names      constant name_array := name_array
                           ('APEX_SCHEMAS');

    apex_pkg_names       constant name_array := name_array
                           ('ORDS_MIGRATE');

    apex_pubsyn_names    constant name_array := name_array
                           ('ORDS_MIGRATE');

    dm_pkg_names         constant name_array := name_array
                           ('OSDDM_DBMS_MD_DDL');

    dm_pubsyn_names      constant name_array := name_array
                           ('OSDDM_DBMS_MD_DDL');

    ords_schema          constant varchar2(30) := 'ORDS_METADATA';                            
    ords_public_user     constant varchar2(30) := 'ORDS_PUBLIC_USER';                            

    obj_counter          counter_array;
    core_objs            counter_array;
    core_pubsyn_objs     counter_array;
    apex_objs            counter_array;
    apex_pubsyn_objs     counter_array;
    dm_objs              counter_array;
    dm_pubsyn_objs       counter_array;

    curr_obj_type        varchar2(255) := 'UNKNOWN';
    ndx_obj_type         varchar2(255);
    err_msg              varchar2(1000) := '';

    total_objs           pls_integer := 0;
    total_invalid_objs   pls_integer := 0;
    total_missing_objs   pls_integer := 0;


    procedure show_log(msg in varchar2 default null) is
    begin
       dbms_output.put_line('VALIDATION: ' || to_char(SYSDATE,'HH24:MI:SS') || ' ' || msg);
    end show_log;

    procedure display_obj_stats is
    begin
       -- Display the stats  
       show_log('Total objects: ' || total_objs || ', invalid objects: ' || total_invalid_objs || ', missing objects: ' || total_missing_objs);

       -- Display the total count for each object type
       ndx_obj_type := obj_counter.first;
       while (ndx_obj_type is not null) loop
          show_log(lpad(to_char(obj_counter(ndx_obj_type)),6) || '  ' || ndx_obj_type);
          ndx_obj_type := obj_counter.next(ndx_obj_type);
       end loop;
    end display_obj_stats;

   function get_obj_ndx (p_obj_type varchar2, p_obj_name varchar2) 
      return varchar2 as
   begin
      return p_obj_type || ' ' || p_obj_name;
   end get_obj_ndx;

   function get_granted_role_ndx (p_user varchar2, p_obj_type varchar2, p_obj_name varchar2) 
      return varchar2 as
   begin
      return p_user || ' ' || get_obj_ndx(p_obj_type, p_obj_name);
   end get_granted_role_ndx;

   procedure init is
      l_obj_ndx        varchar2(255) := '';
      l_granted_role   varchar2(255) := '';
   begin
      --------------------------------------------
      -- The core_objs keeps tracks if an ords database object was created.
      -- 
      -- Initialize values to 0
      for i in 1..tbl_names.count loop
        core_objs(get_obj_ndx(c_table_type, tbl_names(i))) := 0;
      end loop;

      for i in 1..pkg_names.count loop
         core_objs(get_obj_ndx(c_pkg_type, pkg_names(i))) := 0;
         if (pkg_names(i) != 'ORDS_CONSTANTS') then
            core_objs(get_obj_ndx(c_pkg_body_type, pkg_names(i))) := 0;
         end if;
      end loop;

      for i in 1..proc_names.count loop
         core_objs(get_obj_ndx(c_proc_type, proc_names(i))) := 0;
      end loop;

      for i in 1..role_names.count loop
         if role_names(i) = 'ORDS_RUNTIME_USER' then
            l_obj_ndx := get_granted_role_ndx(ords_schema, c_granted_role, role_names(i));
            core_objs(l_obj_ndx) := 0;

            -- ORDS_PUBLIC_USER is only assigned the ORDS_RUNTIME_ROLE
            l_obj_ndx := get_granted_role_ndx(ords_public_user, c_granted_role, role_names(i));
            core_objs(l_obj_ndx) := 0;
         else
            l_obj_ndx := get_granted_role_ndx(ords_schema, c_granted_role, role_names(i));
            core_objs(l_obj_ndx) := 0;
         end if;
      end loop;

      for i in 1..seq_names.count loop
         core_objs(get_obj_ndx(c_seq_type, seq_names(i))) := 0;
      end loop;

      for i in 1..view_names.count loop
         core_objs(get_obj_ndx(c_view_type, view_names(i))) := 0;
      end loop;      

      --------------------------------------------
      -- The core pubsyn_objs keeps tracks if a public synonym object was created.
      -- 
      for i in 1..pubsyn_names.count loop
         l_obj_ndx := 'PUBLIC ' || get_obj_ndx(c_syn_type, pubsyn_names(i));
         core_pubsyn_objs(l_obj_ndx) := 0;
      end loop;

      --------------------------------------------
      -- The apex_objs keeps tracks of the apex related objs.
      -- 
      for i in 1..apex_view_names.count loop
         apex_objs(get_obj_ndx(c_view_type, apex_view_names(i))) := 0;
      end loop;

      for i in 1..apex_pkg_names.count loop
         apex_objs(get_obj_ndx(c_pkg_type, apex_pkg_names(i))) := 0;
         apex_objs(get_obj_ndx(c_pkg_body_type, apex_pkg_names(i))) := 0;
      end loop;

      for i in 1..apex_pubsyn_names.count loop
         l_obj_ndx := 'PUBLIC ' || get_obj_ndx(c_syn_type, apex_pubsyn_names(i));
         apex_pubsyn_objs(l_obj_ndx) := 0;
      end loop;

      --------------------------------------------
      -- The dm_objs keeps tracks of the data modeller objs.
      -- 
      for i in 1..dm_pkg_names.count loop
         dm_objs(get_obj_ndx(c_pkg_type, dm_pkg_names(i))) := 0;
         dm_objs(get_obj_ndx(c_pkg_body_type, dm_pkg_names(i))) := 0;
      end loop;

      for i in 1..dm_pubsyn_names.count loop
         l_obj_ndx := 'PUBLIC ' || get_obj_ndx(c_syn_type, dm_pubsyn_names(i));
         dm_pubsyn_objs(l_obj_ndx) := 0;
      end loop;

   end init;

   procedure track_objs (p_obj_type in varchar2, p_obj_name in varchar2) is
      l_obj_ndx varchar2(255) := '';
   begin
      if p_obj_type in ('TABLE', 'VIEW', 'PACKAGE', 'PACKAGE BODY', 'PROCEDURE', 'SEQUENCE', 'ROLE') then
         l_obj_ndx := get_obj_ndx(p_obj_type, p_obj_name);

         if core_objs.exists(l_obj_ndx) then
            -- show_log('INFO: Tracking object: ' || l_obj_ndx);
            core_objs(l_obj_ndx) := core_objs(l_obj_ndx) + 1;
         elsif apex_objs.exists(l_obj_ndx) then
            apex_objs(l_obj_ndx) := apex_objs(l_obj_ndx) + 1;            
         else
            show_log('INFO: ' || l_obj_ndx || ' is not in the validation list.');
         end if;
      end if;
   end track_objs;

   procedure invalid_obj (p_obj_type in varchar2, p_obj_name in varchar2) is
      l_obj_ndx varchar2(255) := '';
   begin
      total_invalid_objs := total_invalid_objs + 1;
      show_log('WARNING: ' || p_obj_type || ' ' || p_obj_name || ' status is INVALID.');
   end invalid_obj;

   procedure check_missing_objects(p_lookup_obj counter_array) is
      l_err_msg  varchar2(500) := '';
      l_obj_ndx  varchar2(255) := '';
      l_value    pls_integer := 0;
   begin
      l_obj_ndx := p_lookup_obj.first;
      while (l_obj_ndx is not null) loop
         l_err_msg := '';
         l_value   := p_lookup_obj(l_obj_ndx);

         if l_value = 0 then
            if apex_objs.exists(l_obj_ndx) or apex_pubsyn_objs.exists(l_obj_ndx) or
               dm_objs.exists(l_obj_ndx) or dm_pubsyn_objs.exists(l_obj_ndx) then
               -- Apex or data modeler objects that are not core
               -- may have not yet been created during the install.
               -- dbms_output.put_line('INFO: ' || l_obj_ndx || ' has not yet been created.');
               null;
            else
               total_missing_objs := total_missing_objs + 1;
               l_err_msg := 'ERROR: Missing ' || l_obj_ndx;
            end if;
         elsif l_value > 1 then
            l_err_msg := 'ERROR: Counting core objects for ' || l_obj_ndx || ' total = ' || to_char(l_value);
         end if;

         if l_err_msg is not null then
            show_log(l_err_msg);
         end if;

         l_obj_ndx := p_lookup_obj.next(l_obj_ndx);         
      end loop;
   end check_missing_objects;

   procedure check_invalid_objects is
   begin
     --------------------------------------------
     -- Loop over all objects owned by ORDS_METADATA
     --
     for c1 in (select object_name, object_type, status
                from sys.dba_objects
                where owner = ords_schema
                order by object_type, object_name)
     loop
        total_objs := total_objs + 1;
        --
        -- Determine object type and keep track of the total number of objects
        --
        if (c1.object_type != curr_obj_type) then
           -- New object type index and initialize to 1
           obj_counter(c1.object_type) := 1;
           curr_obj_type := c1.object_type;
        else
           obj_counter(c1.object_type) := obj_counter(c1.object_type) + 1;    
        end if;

        --
        -- Keep track of the core objects
        --
       track_objs(c1.object_type, c1.object_name);

       -- 
       -- Display error for objects that are still invalid
       --
       if (c1.status = 'INVALID') then                           
          invalid_obj(c1.object_type, c1.object_name);
       end if;

     end loop;  
   end check_invalid_objects;

   procedure check_role_privs is
      l_obj_ndx  varchar2(255) := '';     
   begin
      show_log('Validating roles granted to ' || ords_schema || ' and ' || ords_public_user);
      for c1 in (select * from sys.dba_role_privs
                where grantee in ('ORDS_METADATA','ORDS_PUBLIC_USER') and granted_role in ('ORDS_RUNTIME_ROLE', 'ORDS_ADMINISTRATOR_ROLE'))
      loop
         l_obj_ndx := get_granted_role_ndx(c1.grantee, c_granted_role, c1.granted_role);
         if core_objs.exists(l_obj_ndx) then
            core_objs(l_obj_ndx) := 1;
         end if;
      end loop;
   end check_role_privs;

   procedure validate_public_synonyms is
      c_obj_type       constant varchar2(30)  := 'PUBLIC SYNONYM';
      c_alter_pub_syn  constant varchar2(100) := 'alter public synonym ';
      c_comp           constant varchar2(10)  := ' compile';
      l_total          pls_integer := 0;
      l_ddl varchar2(200);
      l_obj_ndx  varchar2(255) := '';
      l_obj_name varchar2(255) := '';
   begin
      show_log('Validating ORDS Public Synonyms');
      -- Recompile the public synonyms that are invalid
      for c1 in 
         (select object_name, object_type, status from sys.dba_objects 
             where object_name in (select synonym_name from sys.all_synonyms 
                                   where table_owner=ords_schema and owner='PUBLIC') 
                   and object_type='SYNONYM' and owner= 'PUBLIC' order by object_name)
      loop
         l_total := l_total + 1;

         if (c1.status = 'INVALID') then
            begin
               -- Compile public synonym
	            l_ddl := c_alter_pub_syn || dbms_assert.enquote_name(c1.object_name,FALSE) || c_comp;
	            -- l_ddl := c_alter_pub_syn || c1.object_name || c_comp;
               dbms_output.put_line(l_ddl);
               execute immediate l_ddl;
               dbms_output.put_line('Public Synonym ' || c1.object_name || ' compiled.');
            exception
               when others then
                  show_log('ERROR: '||sqlerrm);
                  show_log('ERROR: Cannot compile public synonym: '||l_ddl);
                  total_invalid_objs := total_invalid_objs + 1;
            end;
         end if;

         l_obj_ndx := 'PUBLIC ' || get_obj_ndx(c1.object_type, c1.object_name);

         if core_pubsyn_objs.exists(l_obj_ndx) then
            core_pubsyn_objs(l_obj_ndx) := core_pubsyn_objs(l_obj_ndx) + 1;
         elsif apex_pubsyn_objs.exists(l_obj_ndx) then
            apex_pubsyn_objs(l_obj_ndx) := apex_pubsyn_objs(l_obj_ndx) + 1;
         elsif dm_pubsyn_objs.exists(l_obj_ndx) then
            dm_pubsyn_objs(l_obj_ndx) := dm_pubsyn_objs(l_obj_ndx) + 1;
         else
            show_log('INFO: PUBLIC ' || c1.object_type || ' ' || c1.object_name || ' is not in the validation list.');
         end if;
      end loop;

      obj_counter(c_obj_type) := l_total;
      total_objs := total_objs + l_total;

      check_missing_objects(core_pubsyn_objs);
   end validate_public_synonyms;

begin

  show_log('Starting validation for schema: ' || ords_schema);
  init;
  show_log('Validating objects');  

  --------------------------------------------
  -- Recompile objects that are invalid
  --
  dbms_utility.compile_schema(schema => ords_schema,
                              compile_all => FALSE);
  --                             
  -- Check for invalid status in dba_objects for ORDS_METADATA
  --
  check_invalid_objects;

  --
  -- Check the granted roles for ORDS_METADATA and ORDS_PUBLIC_USER
  check_role_privs;

  --
  -- Check if the required objects are missing
  check_missing_objects(core_objs);

  --
  -- Check if the public synonyms requires compilation
  validate_public_synonyms;

  -- Display the object statistics
  display_obj_stats;

  if (total_invalid_objs = 0) and (total_missing_objs = 0) then
     show_log('Validation completed.');
  else
     err_msg := 'ERROR:';
     if total_invalid_objs > 0 then
        err_msg := err_msg || ' ORDS schema database objects contains INVALID status.';
     end if;

     if total_missing_objs > 0 then
        err_msg := err_msg || ' ORDS schema contains missing database objects.';
     end if;

     raise_application_error(-20006, err_msg);
  end if;


exception
  when others then
     raise_application_error(-20006, 'ERROR: Validating objects failed. ' || sqlerrm);
end validate_ords;
/

