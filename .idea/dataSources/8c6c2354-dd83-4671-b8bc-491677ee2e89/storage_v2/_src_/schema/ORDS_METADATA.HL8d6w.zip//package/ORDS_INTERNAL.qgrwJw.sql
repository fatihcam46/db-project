create PACKAGE               ORDS_INTERNAL AUTHID definer
AS
  C_ADMIN_ONLY_ENABLE_FLAG CONSTANT number := 1;

  /**
  * Record used to stash and restore seesion parameters
  */
  type t_session_stash is record (
    nls_sort            varchar2(1024)          default null
  );

  function stash_session return t_session_stash;
  procedure restore_session (
        p_stash   IN T_SESSION_STASH, 
        p_sqlcode IN NUMBER            DEFAULT NULL, 
        p_sqlerrm IN VARCHAR2          DEFAULT NULL);

  /**
  * This internal package is invoked with definers rights, so it can
  * can execute various privileged actions including altering a user
  * to connect via a proxy user.
  * Therefore access to this package needs to be carefully protected.
  * It MUST NEVER BE accessible from outside it's owning schema.
  */
  /**
  * Enable/disable the specified schema for ORDS access.
  * @param p_enabled If true ORDS access is enabled, if false it is disabled.
  * @param p_schema The name of the schema to enable/disable.
  * @param p_as_admin Allow administration functionality
  */
  PROCEDURE enable_schema(
      p_enabled                  BOOLEAN,
      p_schema                   VARCHAR2,
      p_url_mapping_type         VARCHAR2,
      p_url_mapping_pattern      VARCHAR2,
      p_auto_rest_auth           BOOLEAN,
      p_as_admin                 BOOLEAN);

  /**
  * Enable/disable the specified schema for ORDS access.
  * @param p_schema_name The name of the schema to enable/disable.
  * @param p_schema Created/Updated row for schema.
  * @param p_url_mapping Created/Updated row for URL mapping.
  * @param p_as_admin Allow administration functionality
  * @param p_enabled If true ORDS access is enabled, if false it is disabled.
  * @param p_url_mapping_type Type of the URL mapping. NULL leaves unchanged or default.
  * @param p_url_mapping_pattern The URL mapping pattern.
  * @param p_auto_rest_auth True if authentication is required prior to actioning by default, otherwise  
  *                         no authenication is required by default.
  */
  PROCEDURE enable_schema(
      p_schema_name         IN            ords_schemas.parsing_schema%type,
      p_schema              OUT NOCOPY    ords_schemas%rowtype,
      p_url_mapping         OUT NOCOPY    ords_url_mappings%rowtype,
      p_as_admin            IN            BOOLEAN,
      p_enabled             IN            BOOLEAN DEFAULT NULL,
      p_url_mapping_type    IN            ords_url_mappings.type%type DEFAULT NULL,
      p_url_mapping_pattern IN            ords_url_mappings.pattern%type DEFAULT NULL,
      p_auto_rest_auth      IN            BOOLEAN DEFAULT NULL);

  /**
  * Delete autorest ords metadata for the specified schema.
  * @param p_schema The name of the schema's auto rest delete.
  * @param p_as_admin Allow administration functionality
  */
  PROCEDURE delete_schema(
      p_schema              VARCHAR2,
      p_as_admin            BOOLEAN);
  /**
  * Enable/disable the specified schema object for ORDS access.
  * @param p_enabled If true ORDS access is enabled, if false it is disabled.
  * @param p_schema The name of the schema to enable/disable.
  * @param p_as_admin Allow administration functionality
  */
  PROCEDURE enable_object(
      p_enabled             BOOLEAN,
      p_schema              VARCHAR2,
      p_object              VARCHAR2,
      p_object_type         VARCHAR2,
      p_object_alias        VARCHAR2,
      p_type_path           BOOLEAN,
      p_auto_rest_auth      BOOLEAN,
      p_as_admin            BOOLEAN);

  /**
  * Delete autorest ords metadata for the specified schema.
  * @param p_schema The name of the schema's auto rest delete.
  */
  PROCEDURE delete_object(
      p_schema              VARCHAR2,
      p_object              VARCHAR2);

  /**
  * Configure how the sepcified schema is mapped to request URLs
  * @param p_schema The name of the schema to map.
  * @param p_url_mapping_type The URL Mapping type, 'BASE_PATH' or 'BASE_URL'.
  * @param p_url_mapping_pattern The URL Mapping pattern.
  */
  PROCEDURE set_url_mapping(
      p_schema              VARCHAR2,
      p_url_mapping_type    VARCHAR2,
      p_url_mapping_pattern VARCHAR2);


  /**
  * Check if user in the ORDS_METADATA schema
  */
  FUNCTION is_metadata_schema(
      p_user   VARCHAR2)
    RETURN BOOLEAN;

  FUNCTION installed_version RETURN VARCHAR2;

  PROCEDURE AUTOREST_SCHEMA_SYNCHRONISE(
      P_EVENT VARCHAR2,
      P_OWNER VARCHAR2,
      P_OBJECT VARCHAR2,
      P_TYPE VARCHAR2);

  PROCEDURE CLEAN_OLD_SESSIONS;

-- Deprecated

  /**
   * @deprecated Use procedure with p_user argument
   */
  PROCEDURE enable_schema(
      p_enabled                  BOOLEAN,
      p_schema                   VARCHAR2,
      p_url_mapping_type         VARCHAR2,
      p_url_mapping_pattern      VARCHAR2,
      p_auto_rest_auth           BOOLEAN,
      p_user                     VARCHAR2);

  /**
   * @deprecated Use procedure with p_user argument
   */
  PROCEDURE delete_schema(
      p_schema              VARCHAR2,
      p_user                VARCHAR2);

  /**
   * @deprecated Use procedure with p_user argument
   */
  PROCEDURE enable_object(
      p_enabled             BOOLEAN,
      p_schema              VARCHAR2,
      p_object              VARCHAR2,
      p_object_type         VARCHAR2,
      p_object_alias        VARCHAR2,
      p_type_path           BOOLEAN,
      p_auto_rest_auth      BOOLEAN,
      p_user                VARCHAR2);

  /**
   * @deprecated Use procedure with p_user argument
   */
  PROCEDURE set_url_mapping(
      p_schema              VARCHAR2,
      p_url_mapping_type    VARCHAR2,
      p_url_mapping_pattern VARCHAR2,
      p_user                VARCHAR2);

  /**
   * Determine the schema id associated with the specified schema
   * @param p_schema indicates the schema to determine a schema_id for. If p_schema is null then the current schema is used. The current user is checked to ensure they have access to the schema
   * @return schema_id of the current schema or the schema specified by p_schema
   */
  function schema_id(p_schema varchar2) return number;
  function has_sysoper_role return boolean;
  function has_dba_role(p_user varchar2) return boolean;
  function has_admin_priv(p_user varchar2) return boolean;

    /**
   * Check the specified object for ORDS support.
   * Returns a list of unsupported object attributes.
   * Only DBA users can check an objects support other than their own.
   * Only objects fully supported by ORDS can be enabled.
   *
   * @param p_schema       The name of the schema with access to the database object.
   *
   * @param p_object       The name of the database object.
   *
   * @param p_object_type  The database object type as configured in the Oracle catalog.
   */
  FUNCTION check_object_support(
      p_schema              IN ords_schemas.parsing_schema%type,
      p_object              IN ords_objects.parsing_object%type,
      p_object_type         IN ords_objects.type%type)
    RETURN t_ords_attr_support_tab;

  /**
   * Perform housekeeping activities immediately
   */
  PROCEDURE perform_housekeeping;

  /**
   * Enable/disable housekeeping job
   * @param p_enabled      True if job is to be enabled, otherwise disabled.
   */
  PROCEDURE enable_housekeeping_job(
      p_enabled             IN boolean);

  /**
   * Drop housekeeping job
   */
  PROCEDURE drop_housekeeping_job;

  /**
   * Set defaults that apply for the duration of the database session.
   *
   * @param p_runtime_user             All other runtime users will be ignored except this one
   */
  PROCEDURE set_session_defaults(
      p_as_admin            IN            boolean,
      p_runtime_user        IN            varchar2);

  /**
   * Reset session defaults back to initial values
   */
  PROCEDURE reset_session_defaults(
      p_as_admin            IN            boolean);

  /**
   * Provision a database user so it can act as an ORDS Runtime User. e.g. ORDS_PUBLIC_USER.
   *
   * @param p_user                     The name of the user to be configured.
   *
   * @param p_proxy_enabled_schemas    When true, proxy grants will be added for any enabled schemas.
   */
  PROCEDURE provision_runtime_role(
      p_user                  IN          varchar2,
      p_proxy_enabled_schemas IN          boolean DEFAULT FALSE);

  /**
   * Provision a database user with the ORDS Administrator role so they can administer ORDS
   * User ORDS_PUBLIC_USER cannot be configured using this interface.
   *
   * @param p_user                 The name of the user to be provisioned.
   */
  PROCEDURE provision_admin_role(
      p_user               IN            varchar2);

  /**
   * Unprovision ORDS database roles.
   *
   * User ORDS_PUBLIC_USER cannot be unprovisioned as a runtime user using this interface.
   * use the uninstaller to configue this user.
   *
   * @param p_user                 The name of the user to be unprovisioned.
   *
   * @param p_administrator_role   Unprovision as Admin User.
   *
   * @param p_runtime_role         Unprovision as Runtime User.
   */
  PROCEDURE unprovision_roles(
      p_user               IN            varchar2,
      p_administrator_role IN            boolean DEFAULT NULL,
      p_runtime_role       IN            boolean DEFAULT NULL);

  /**
   * Configure PL/SQL Gateway.
   *
   * Configures the database proxy user that must be used for PL/SQL Gateway calls serviced by the specified Runtiume User.
   *
   * Note: A NULL boolean value for p_proxy_user will remove any existing configuration.
   *
   * @param p_runtime_user         The name of the runtime user to be configured.
   *
   * @param p_proxy_user           The name of the proxy user.
   */
  PROCEDURE config_plsql_gateway(
      p_runtime_user       IN            varchar2,
      p_plsql_gateway_user IN            varchar2,
      p_comments           IN            varchar2 DEFAULT NULL);
END ords_internal;
/

