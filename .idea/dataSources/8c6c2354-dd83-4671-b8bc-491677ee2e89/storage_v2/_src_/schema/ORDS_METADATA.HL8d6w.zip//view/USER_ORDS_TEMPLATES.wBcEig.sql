create view USER_ORDS_TEMPLATES as
SELECT ords_templates."ID",ords_templates."MODULE_ID",ords_templates."URI_TEMPLATE",ords_templates."PRIORITY",ords_templates."ETAG_TYPE",ords_templates."ETAG_QUERY",ords_templates."COMMENTS",ords_templates."SCHEMA_ID",ords_templates."CREATED_BY",ords_templates."CREATED_ON",ords_templates."UPDATED_BY",ords_templates."UPDATED_ON"
FROM ords_templates,
  ords_schemas
WHERE ords_schemas.id           = ords_templates.schema_id
AND nlssort(ords_schemas.parsing_schema,'NLS_SORT=BINARY') = nlssort(sys_context('USERENV', 'CURRENT_USER'),'NLS_SORT=BINARY')
/

