create TYPE  t_ords_module UNDER t_ords_metadata_type
   ("NAME"           VARCHAR2(255 BYTE), 
    "BASE_PATH"      VARCHAR2(255 BYTE), 
    "ITEMS_PER_PAGE" NUMBER, 
    "STATUS"         VARCHAR2(30 BYTE), 
    "TEMPLATE_LIST"  t_ords_template_list, 
    CONSTRUCTOR FUNCTION T_ORDS_MODULE (
      name               IN VARCHAR2,
      base_path          IN VARCHAR2,
      items_per_page     IN NUMBER   DEFAULT 25,
      status             IN VARCHAR2 DEFAULT 'PUBLISHED',
      comments           IN VARCHAR2 DEFAULT NULL,
      template_list      IN t_ords_template_list,
      created_on         IN DATE     DEFAULT NULL,
      created_by         IN VARCHAR2 DEFAULT NULL,
      updated_on         IN DATE     DEFAULT NULL,
      updated_by         IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT,
    CONSTRUCTOR FUNCTION T_ORDS_MODULE (
      name               IN VARCHAR2,
      base_path          IN VARCHAR2,
      items_per_page     IN NUMBER   DEFAULT 25,
      status             IN VARCHAR2 DEFAULT 'PUBLISHED',
      comments           IN VARCHAR2 DEFAULT NULL,
      template           IN t_ords_template DEFAULT NULL,
      created_on         IN DATE     DEFAULT NULL,
      created_by         IN VARCHAR2 DEFAULT NULL,
      updated_on         IN DATE     DEFAULT NULL,
      updated_by         IN VARCHAR2 DEFAULT NULL
    ) RETURN SELF AS RESULT
   );
/

