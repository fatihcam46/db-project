create view APEX_WWV_FLOW_POOL_CONFIG as
select 
    null pool_name, 
	rpad('dummy',128) schema_name, 
	rpad('dummy',255) workspace_name, 
	rpad('dummy',128) workspace_identifier, 
	rpad('dummy',255) uri, 
	rpad('BASE_PATH',9) type, 
	sysdate updated, 1 tenant_id,   
	rpad('none',255) 
	identity_domain 
  from sys.dual 
  where 1 <> 1
/

